%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PCA of spike trains from renewal point processes.
%
% DATASET GENERATION:
% Spike trains were generated as an Homogeneous Renewal Point Process,
% with either a lognormal or gamma ISI distribution.
%
% Antonio Paiva
% May 2008
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear; close all
rand('seed', 20080309);
randn('seed',20080309);

%% settings
%=====================================================================

nTrainSpikeTrains = 50;
nTestSpikeTrains = 200;

kfunc = 'gaussian';		% kernel to use in the mCI kernel estimator
ksize = 50E-3;			% width/bin size/kernel for smoothing function
						% and kernel size for mCI estimator
Kkernelsize = 1;		% Gaussian kernel size for nCIk2

% renewal point processes parameters
distrib = 'gamma';
distrib_param = [0.5 3];
T = 1;					% length of each spike train (sec)
rate = 20;

%% generate spike trains
%=====================================================================

% generate training data
stSetTrain = cell(nTrainSpikeTrains,1);
for i = 1:2
	for j = 1:nTrainSpikeTrains/2
		idx = (i-1)*(nTrainSpikeTrains/2) + j;
		while (1)
			stSetTrain{idx} = generateHomogeneousRenewalSpikeTrain(...
									rate, T, distrib, distrib_param(i));
			if (length(stSetTrain{idx}) > 0), break; end
		end
	end
end
stSetTrain1 = stSetTrain(1:nTrainSpikeTrains/2);
stSetTrain2 = stSetTrain(nTrainSpikeTrains/2+1:end);

% generate test data
stSetTest = cell(nTestSpikeTrains,1);
for i = 1:2
	for j = 1:nTestSpikeTrains/2
		idx = (i-1)*(nTestSpikeTrains/2) + j;
		while (1)
			stSetTest{idx} = generateHomogeneousRenewalSpikeTrain(...
									rate, T, distrib, distrib_param(i));
			if (length(stSetTest{idx}) > 0), break; end
		end
	end
end
stSetTest1 = stSetTest(1:nTestSpikeTrains/2);
stSetTest2 = stSetTest(nTestSpikeTrains/2+1:end);

% plot spike trains
figure;
h = (nTestSpikeTrains / (nTrainSpikeTrains + nTestSpikeTrains)) * 0.8;
ax = axes('position', [0.13 (0.1 + h + 0.05) 0.85 (0.8 - h)]);
set(gca, 'FontSize',14);
plot_spk_trains(stSetTrain, T, 1);
set(gca, 'Xtick', []); xlabel('');
ylabel('training')
ax = axes('position', [0.13 0.1 0.85 h]);
set(gca, 'FontSize',14);
plot_spk_trains([stSetTest1; stSetTest2], T, 1);
ylabel('testing'), xlabel('time (s)');
%
ax = axes('position', [0 0.95 0.05 0.05]);
set(gca, 'Visible','off');
text(0, 0, 'A', 'HorizontalAlignment','left', ...
	'FontSize', 16, 'FontWeight', 'bold');
ax = axes('position', [0 (0.1 + h) 0.05 0.05]);
set(gca, 'Visible','off');
text(0, 0, 'B', 'HorizontalAlignment','left', ...
	'FontSize', 16, 'FontWeight', 'bold');
saveas(gcf, 'figs/fig_pcaRenewal_spkTrains.png','png');
saveas(gcf, 'figs/fig_pcaRenewal_spkTrains.eps','eps2');


%% compute PCA with mCI kernel
%=====================================================================

fprintf('Computing mCI PCA...\n');
mcik_handler = @(arg1, arg2) mcik({arg1,arg2}, ksize, kfunc);

% compute principal components
m_pca = fpca(stSetTrain, mcik_handler);

% project the training data
m_projTrain1 = project2PCA(m_pca, stSetTrain1, 1:2);
m_projTrain2 = project2PCA(m_pca, stSetTrain2, 1:2);

% project the test data
m_projTest1 = project2PCA(m_pca, stSetTest1, 1:2);
m_projTest2 = project2PCA(m_pca, stSetTest2, 1:2);

% eigenvalues
figure;
plot(abs(m_pca.rho), 's-');
set(gca,'Box','on','FontSize',14);
xlabel('index'), ylabel('eigenvalues')
saveas(gcf, 'figs/fig_pcaRenewal_mCI_eigval.png','png');
saveas(gcf, 'figs/fig_pcaRenewal_mCI_eigval.eps','epsc2');

% first two eigenvectors of Gram matrix
figure; hold all
plot(m_pca.b(:,1), 'o-', 'LineWidth',1.5);
plot(m_pca.b(:,2), 'x--', 'LineWidth',1.5);%,'Color',0.5.*[1 1 1]);
legend('first eigenvector','second eigenvector', 'Location','SouthEast');
set(gca,'Box','on','FontSize',14);
xlabel('index'), ylabel('eigenvector coefficient'), %ylim([-.4 .42])
saveas(gcf, 'figs/fig_pcaRenewal_mCI_eigvec.png','png');
saveas(gcf, 'figs/fig_pcaRenewal_mCI_eigvec.eps','epsc2');

% projected training data
figure;
plot(m_projTrain1(:,1), m_projTrain1(:,2), 'o', ...
	'MarkerSize',9,'LineWidth',3)
hold all
plot(m_projTrain2(:,1), m_projTrain2(:,2), 'x', ...
	'MarkerSize',12,'LineWidth',3)
%title('Projected training data');
xlabel('PC1'), ylabel('PC2')
saveas(gcf, 'figs/fig_pcaRenewal_mCI_projTrain.png','png');
saveas(gcf, 'figs/fig_pcaRenewal_mCI_projTrain.eps','epsc2');

% projected testing data
figure;
plot(m_projTest1(:,1), m_projTest1(:,2), 'o', ...
	'MarkerSize',9,'LineWidth',3)
hold all
plot(m_projTest2(:,1), m_projTest2(:,2), 'x', ...
	'MarkerSize',12,'LineWidth',3)
%title('Projected testing data');
xlabel('PC1'), ylabel('PC2')
saveas(gcf, 'figs/fig_pcaRenewal_mCI_projTest.png','png');
saveas(gcf, 'figs/fig_pcaRenewal_mCI_projTest.eps','epsc2');

% Gram matrix
figure
imagesc(m_pca.Itilde - diag(diag(m_pca.Itilde)));
saveas(gcf, 'figs/fig_pcaRenewal_mCI_gramMtx.png','png');
saveas(gcf, 'figs/fig_pcaRenewal_mCI_gramMtx.eps','epsc2');


%% compute PCA with nCI kernel
%=====================================================================

fprintf('Computing nCI PCA...\n');
ncik_handler = @(arg1, arg2) ncik2({arg1,arg2}, T, ksize, Kkernelsize);

% compute principal components
n_pca = fpca(stSetTrain, ncik_handler);

% project the training data
fprintf('Projecting training data...\n');
n_projTrain1 = project2PCA(n_pca, stSetTrain1, 1:2);
n_projTrain2 = project2PCA(n_pca, stSetTrain2, 1:2);

% project the test data
fprintf('Projecting testing data...\n');
n_projTest1 = project2PCA(n_pca, stSetTest1, 1:2);
n_projTest2 = project2PCA(n_pca, stSetTest2, 1:2);

% eigenvalues
figure;
plot(abs(n_pca.rho), 's-');
set(gca,'Box','on','FontSize',14);
xlabel('index'), ylabel('eigenvalues')
saveas(gcf, 'figs/fig_pcaRenewal_nCI_eigval.png','png');
saveas(gcf, 'figs/fig_pcaRenewal_nCI_eigval.eps','epsc2');

% first two eigenvectors of Gram matrix
figure; hold all
plot(n_pca.b(:,1), 'o-', 'LineWidth',1.5);
plot(n_pca.b(:,2), 'x--', 'LineWidth',1.5);%,'Color',0.5.*[1 1 1]);
legend('first eigenvector','second eigenvector', 'Location','SouthEast');
set(gca,'Box','on','FontSize',14);
xlabel('index'), ylabel('eigenvector coefficient'), ylim([-.6 .5])
saveas(gcf, 'figs/fig_pcaRenewal_nCI_eigvec.png','png');
saveas(gcf, 'figs/fig_pcaRenewal_nCI_eigvec.eps','epsc2');

% projected training data
figure;
plot(n_projTrain1(:,1), n_projTrain1(:,2), 'o', ...
	'MarkerSize',9,'LineWidth',3)
hold all
plot(n_projTrain2(:,1), n_projTrain2(:,2), 'x', ...
	'MarkerSize',12,'LineWidth',3)
%title('Projected training data');
xlabel('PC1'), ylabel('PC2')
saveas(gcf, 'figs/fig_pcaRenewal_nCI_projTrain.png','png');
saveas(gcf, 'figs/fig_pcaRenewal_nCI_projTrain.eps','epsc2');

% projected testing data
figure;
plot(n_projTest1(:,1), n_projTest1(:,2), 'o', ...
	'MarkerSize',9,'LineWidth',3)
hold all
plot(n_projTest2(:,1), n_projTest2(:,2), 'x', ...
	'MarkerSize',12,'LineWidth',3)
%title('Projected testing data');
xlabel('PC1'), ylabel('PC2'), axis([-1.7 2 -0.35 0.45])
saveas(gcf, 'figs/fig_pcaRenewal_nCI_projTest.png','png');
saveas(gcf, 'figs/fig_pcaRenewal_nCI_projTest.eps','epsc2');

% Gram matrix
figure
imagesc(n_pca.Itilde - diag(diag(n_pca.Itilde)));
saveas(gcf, 'figs/fig_pcaRenewal_nCI_gramMtx.png','png');
saveas(gcf, 'figs/fig_pcaRenewal_nCI_gramMtx.eps','epsc2');


%% compute PCA with IP_Hougton
%  (using nonlinear approximation; see book chapter edited by Karim Oweiss)
%=====================================================================

gmax = [1 2 3 5 10 20 40];
for k = 1:length(gmax)
	fprintf('*** IPH: gmax = %d\n', gmax(k));
	gs = sprintf('gmax%02d',gmax(k));

	iph_handler = @(arg1, arg2) ...
					iphnf({arg1,arg2}, T, ksize, gmax(k), 'tanh', 'exp');
	
	% compute principal components
	n_pca = fpca(stSetTrain, iph_handler);
	fprintf('Computed PCA.\n');
	
	% project the training data
	n_projTrain1 = project2PCA(n_pca, stSetTrain1, 1:2);
	n_projTrain2 = project2PCA(n_pca, stSetTrain2, 1:2);
	fprintf('Projected training data.\n');
	
	% project the test data
	n_projTest1 = project2PCA(n_pca, stSetTest1, 1:2);
	n_projTest2 = project2PCA(n_pca, stSetTest2, 1:2);
	fprintf('Projected testing data.\n');

	% eigenvalues
	figure;
	plot(abs(n_pca.rho), 's-');
	set(gca,'Box','on','FontSize',14);
	xlabel('index'), ylabel('eigenvalues')
	saveas(gcf, ['figs/fig_pcaRenewal_iphnf_eigval_' gs],'png');
	saveas(gcf, ['figs/fig_pcaRenewal_iphnf_eigval_' gs],'epsc2');
	
	% first two eigenvectors of Gram matrix
	figure; hold all
	plot(n_pca.b(:,1), 'o-', 'LineWidth',1.5);
	plot(n_pca.b(:,2), 'x--', 'LineWidth',1.5);%,'Color',0.5.*[1 1 1]);
	legend('first eigenvector','second eigenvector', 'Location','SouthEast');
	set(gca,'Box','on','FontSize',14);
	xlabel('index'), ylabel('eigenvector coefficient'), %ylim([-.45 .45])
	saveas(gcf, ['figs/fig_pcaRenewal_iphnf_eigvec_' gs],'png');
	saveas(gcf, ['figs/fig_pcaRenewal_iphnf_eigvec_' gs],'epsc2');
	
	% projected training data
	figure;
	plot(n_projTrain1(:,1), n_projTrain1(:,2), 'o', ...
		'MarkerSize',9,'LineWidth',3)
	hold all
	plot(n_projTrain2(:,1), n_projTrain2(:,2), 'x', ...
		'MarkerSize',12,'LineWidth',3)
	%title('Projected training data');
	xlabel('PC1'), ylabel('PC2')
	saveas(gcf, ['figs/fig_pcaRenewal_iphnf_projTrain_' gs],'png');
	saveas(gcf, ['figs/fig_pcaRenewal_iphnf_projTrain_' gs],'epsc2');
	
	% projected testing data
	figure;
	plot(n_projTest1(:,1), n_projTest1(:,2), 'o', ...
		'MarkerSize',9,'LineWidth',3)
	hold all
	plot(n_projTest2(:,1), n_projTest2(:,2), 'x', ...
		'MarkerSize',12,'LineWidth',3)
	%title('Projected testing data');
	xlabel('PC1'), ylabel('PC2')
	saveas(gcf, ['figs/fig_pcaRenewal_iphnf_projTest_' gs],'png');
	saveas(gcf, ['figs/fig_pcaRenewal_iphnf_projTest_' gs],'epsc2');
	
	% Gram matrix
	figure
	imagesc(n_pca.Itilde - diag(diag(n_pca.Itilde)));
	saveas(gcf, ['figs/fig_pcaRenewal_iphnf_gramMtx_' gs],'png');
	saveas(gcf, ['figs/fig_pcaRenewal_iphnf_gramMtx_' gs],'epsc2');
end


% %% compute PCA with IP_Hougton (inner product corresponding to the b-metric)
% %=====================================================================
% 
% mu = [0.1:0.1:0.9 0.95 0.98 0.99];
% for k = 1:length(mu)
% 	fprintf('*** IPH: mu = %.2f\n', mu(k));
% 	gs = sprintf('mu%03d', round(100*mu(k)));
% 
% 	iph_handler = @(arg1, arg2) iph1({arg1,arg2}, T, ksize, mu(k));
% 
% 	% compute principal components
% 	n_pca = fpca(stSetTrain, iph_handler);
% 	fprintf('Computed PCA.\n');
% 	
% 	% project the training data
% 	n_projTrain1 = project2PCA(n_pca, stSetTrain1, 1:2);
% 	n_projTrain2 = project2PCA(n_pca, stSetTrain2, 1:2);
% 	fprintf('Projected training data.\n');
% 	
% 	% project the test data
% 	n_projTest1 = project2PCA(n_pca, stSetTest1, 1:2);
% 	n_projTest2 = project2PCA(n_pca, stSetTest2, 1:2);
% 	fprintf('Projected testing data.\n');
% 	
% 	% eigenvalues
% 	figure;
% 	plot(abs(n_pca.rho), 's-');
% 	set(gca,'Box','on','FontSize',14);
% 	xlabel('index'), ylabel('eigenvalues')
% 	saveas(gcf, ['figs/fig_pcaRenewal_iph1_eigval_' gs],'png');
% 	saveas(gcf, ['figs/fig_pcaRenewal_iph1_eigval_' gs],'epsc2');
% 	
% 	% first two eigenvectors of Gram matrix
% 	figure; hold all
% 	plot(n_pca.b(:,1), 'o-', 'LineWidth',1.5);
% 	plot(n_pca.b(:,2), 'x--', 'LineWidth',1.5);%,'Color',0.5.*[1 1 1]);
% 	legend('first eigenvector','second eigenvector', 'Location','SouthEast');
% 	set(gca,'Box','on','FontSize',14);
% 	xlabel('index'), ylabel('eigenvector coefficient'), ylim([-.45 .45])
% 	saveas(gcf, ['figs/fig_pcaRenewal_iph1_eigvec_' gs],'png');
% 	saveas(gcf, ['figs/fig_pcaRenewal_iph1_eigvec_' gs],'epsc2');
% 	
% 	% projected training data
% 	figure;
% 	plot(n_projTrain1(:,1), n_projTrain1(:,2), 'o', ...
% 		'MarkerSize',9,'LineWidth',3)
% 	hold all
% 	plot(n_projTrain2(:,1), n_projTrain2(:,2), 'x', ...
% 		'MarkerSize',12,'LineWidth',3)
% 	%title('Projected training data');
% 	xlabel('PC1'), ylabel('PC2')
% 	saveas(gcf, ['figs/fig_pcaRenewal_iph1_projTrain_' gs],'png');
% 	saveas(gcf, ['figs/fig_pcaRenewal_iph1_projTrain_' gs],'epsc2');
% 	
% 	% projected testing data
% 	figure;
% 	plot(n_projTest1(:,1), n_projTest1(:,2), 'o', ...
% 		'MarkerSize',9,'LineWidth',3)
% 	hold all
% 	plot(n_projTest2(:,1), n_projTest2(:,2), 'x', ...
% 		'MarkerSize',12,'LineWidth',3)
% 	%title('Projected testing data');
% 	xlabel('PC1'), ylabel('PC2')
% 	saveas(gcf, ['figs/fig_pcaRenewal_iph1_projTest_' gs],'png');
% 	saveas(gcf, ['figs/fig_pcaRenewal_iph1_projTest_' gs],'epsc2');
% 	
% 	% Gram matrix
% 	figure
% 	imagesc(n_pca.Itilde - diag(diag(n_pca.Itilde)));
% 	saveas(gcf, ['figs/fig_pcaRenewal_iph1_gramMtx_' gs],'png');
% 	saveas(gcf, ['figs/fig_pcaRenewal_iph1_gramMtx_' gs],'epsc2');
% end

