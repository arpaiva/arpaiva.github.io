function st = generateInhomogenousRenewalSpikeTrain(fr, T, distrib, shapeParam)
%Generate a realization of an Inhomogeneous Renewal Spike Train.
%
% ST = generateInhomogenousRenewalSpikeTrain(LAMBDA, T, DISTRIB, SHAPEPARAM)
%
% LAMBDA is the intensity function over time, and
% T is the length (in seconds) of the realization
% DISTRIB [optional] defines the distribution of the ISIs:
%   'gamma' (default) or 'lognormal'.
% SHAPEPARAM [optional] shape parameter for the distribution of the ISIs.
%   If this argument is ommited, the distributions take default values:
%   k = 2 for the gamma, and std = 0.5 for the lognormal.
%   (The second parameter is adjusted to obtain the desired rate of events.)
%

% Antonio Paiva, Oct 2007

N = length(fr);
if (N == 1)
	% work like generateHomogeneousRenewalSpikeTrain
	if (exist('distrib') ~= 1)
		distrib = 'gamma';
	end
	if (exist('shapeParam') == 1)
		st = generateHomogeneousRenewalSpikeTrain(fr,T,distrib,shapeParam);
	else
		st = generateHomogeneousRenewalSpikeTrain(fr,T,distrib);
	end
	return;
end
dt = T/N;

% cumulative firing rate for time rescaling
cumulativeFr = zeros(1, length(fr)+1);
for i = 1:length(fr)
	cumulativeFr(i+1) = cumulativeFr(i) + fr(i) * dt;
end

% generate spike trains
if (exist('shapeParam') == 1)
	aux = generateHomogeneousRenewalSpikeTrain(...
			1, cumulativeFr(end), distrib, shapeParam);
else
	aux = generateHomogeneousRenewalSpikeTrain(1, cumulativeFr(end), distrib);
end

% time rescaling
st = zeros(1,length(aux));
for i = 1:length(aux)
	st(i) = dt * min(find(cumulativeFr >= aux(i)));
end

