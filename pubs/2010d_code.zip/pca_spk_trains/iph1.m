function V = iph1(st, T, tau, mu)
%V = IPH1(ST, T, TAU, MU)
% Returns the spike train inner product defined using the membrane
% potential used by Houghton for the b-metric. If more than two neurons 
% are provided, V is the Gram matrix, otherwise it is a scalar.
%
% The inner product is defined as
%    V(s_i,s_j) = \int_0^T f(s_i,t) f(s_j,t) dt
% with g(s_i,t) defined such that,
% 	 f -> (1-\mu) * f + 1,   when a spike arrives, and
%    f -> (1 - dt/\tau) * f, otherwise.
% (mu is a parameter and dt is the time integration step)
%
%         ST: Data, organized in a cell array, with each cell containing an
%             array of spike times (sec).
%          T: Duration of the spike trains (sec).
%        TAU: Width parameter of the smoothing function h (in sec).
%         MU: Scaling parameter of the membrane potential.

% Copyright (c) Antonio Paiva
% last revised: Mar 4, 2010

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
N = length(st);
if (N < 2)
	error('Need at least two neurons to operate');
end
if (nargin < 4)
	error('Unspecified arguments!');
end

% ensure each spike train is a row vector
L = zeros(1,N);
for i = 1:N
	[a b] = size(st{i});
	if (~isempty(st{i}))
		if (a > b)
			st{i} = st{i}(:,1)';
		else
			st{i} = st{i}(1,:);
		end
	end
	L(i) = length(st{i});
end

% compute smoothed spike trains
dt = tau / 10;
t = [0:dt:T];
f = zeros(N, length(t));
for i = 1:N
	if ~isempty(st{i})
		j = 1;
		for n = 1:numel(t)
			if (j <= L(i)) && (st{i}(j) <= t(n))
				% spike!
				% f -> (1-\mu) * f + 1
				f(i,n) = (1 - mu) * f(i,max(1,n-1)) + 1;
				j = j + 1;
			else
				% f -> (1 - dt/\tau) * f
				f(i,n) = (1 - dt/tau) * f(i,max(1,n-1));
			end
		end
	end
end

% compute inner product/kernel matrix
V = zeros(N, 'single');
for i = 1:(N-1)
	for j = i:N
		% numerical evaluation of the integral
		V(i,j) = f(i,:) * f(j,:)';
	end
end
if (N == 2)
	V = V(1,2);
else
	V = V + V' - diag(diag(V));
end

% vim: ts=4
