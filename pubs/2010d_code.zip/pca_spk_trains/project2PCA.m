function values = project2PCA(pca, stCell, componentList)
% project a set of spike trains to given PCA component directions
% Input:
%   pca: the PCA structure obtained from fpca
%   stCell: (Mx1) cell array of spike trains to be projected
%   componentList: the index for PC's. use 1:2 for first 2 PCA components.
%
% Output:
%   values: (MxV) projected values for each spike train and each index
%
% See also: fpca, ex0
%
% $Id: project2PCA.m 230 2007-05-24 19:30:10Z arpaiva $
% Copyright 2007 Antonio and Memming, CNEL, all rights reserved.

M = length(stCell);
values = zeros(M, length(componentList));
innerRep = zeros(pca.N, 1);

centerVec = mean(pca.Itilde, 2);
centerVal = sum(pca.Itilde(:)) ./ (pca.N^2);

for k = 1:M
    for kk = 1:pca.N
        innerRep(kk) = pca.kernel(stCell{k}, pca.stCell{kk});
    end
    innerRep = innerRep - centerVec - mean(innerRep) + centerVal;
    values(k, :) = pca.b(:, componentList)' * innerRep;
end

%for k = 1:M
%    st = stCell{k};
%    for kk = 1:pca.N
%        innerRep(kk) = pca.kernel(st, pca.stCell{kk});
%    end
%    innerRep = innerRep - mean(innerRep);
%    values(k, :) = pca.b(:, componentList)' * innerRep;
%end
%values = values ./ pca.N;

% vim: set ts=8 sts=4 sw=4: (modeline)
