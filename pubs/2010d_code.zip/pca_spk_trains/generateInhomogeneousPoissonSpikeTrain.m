function st = generateInhomogenousPoisonSpikeTrain(fr,T)
%Generate a realization of an Inhomogeneous Poisson Spike Train.
%
% ST = generateInhomogenousPoisonSpikeTrain(LAMBDA,T)
%
% LAMBDA is the intensity function over time, and
% T is the length (in seconds) of the realization

% Antonio Paiva, Oct 2007

N = length(fr);
if (N == 1)
	% work like generateHomogenousPoissonSpikeTrain
	st = generateHomogeneousPoissonSpikeTrain(fr,T);
	return;
end
dt = T/N;

cumulativeFr = zeros(1, length(fr)+1);
for i = 1:length(fr)
	cumulativeFr(i+1) = cumulativeFr(i) + fr(i) * dt;
end

% generate spike trains
aux = generateHomogeneousPoissonSpikeTrain(1, cumulativeFr(end));
st = zeros(1,length(aux));
for i = 1:length(aux)
	st(i) = dt * min(find(cumulativeFr >= aux(i)));
end

