function I = mcik(x, ksize, kern_str)
%I = mCIk(X, KSIZE, [KERNEL])
% Returns the memoryless Cross-Intensity kernel. If more than two neurons are
% provided, I is a vector with the evaluation of all pair combinations (in the
% order: first with all others, second with all others excluding first, ...)
% [MEX version; implemented in mcik.c]
%
%       X: Data, organized as a cell array, with each cell containing an
%          array of spike times (in seconds).
%   KSIZE: Kernel size (in seconds).
%  KERNEL: [optional] String describing which kernel to use in the
%          evaluation of the inner product. Default: 'laplacian'.
%          Other known values are: 'gaussian', 'triangular', and 'rectwin'.

% Copyright (c) Antonio Paiva
% Jul 2007

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% MATLAB implementation
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%
% N = length(x);
% if (N < 2)
% 	error('Need at least two neurons to operate');
% end
% 
% if ((nargin < 3) | strcmp(kern_str, 'laplacian'))
% 	kernel = @(z, tau) exp(-abs(z) ./ tau);
% 	kernel_normalization = 1 / (2*ksize);
% elseif strcmp(kern_str, 'gaussian')
% 	kernel = @(z, sigma) exp(-z.^2 ./ (2*sigma^2));
% 	kernel_normalization = 1 / (sqrt(2*pi)*ksize);
% elseif strcmp(kern_str, 'triangular')
% 	kernel = @(z, q) ((abs(z) < q) .* (1 - abs(z)/q));
% 	kernel_normalization = 1 / ksize;
% elseif strcmp(kern_str, 'rectwin')
% 	kernel = @(z, q) (abs(z) <= q);
% 	kernel_normalization = 1 / (2*ksize);
% else
% 	error('Unknown kernel! Try one: ''laplacian'', ''gaussian'', ''triangular'' and ''rectwin''');
% end
% 
% I = zeros(N*(N-1)/2, 1);
% k = 1;
% for i = 1:(N-1)
% 	for j = (i+1):N
% 		for m = 1:length(x{i})
% 			for n = 1:length(x{j})
% 				I(k) = I(k) + kernel(x{i}(m) - x{j}(n), ksize);
% 			end
% 		end
% 		I(k) = I(k) .* kernel_normalization;
% 		k = k+1;
% 	end
% end

