function V = ncik2(st, T, pwidth, ksize, kern_str)
%V = nCIk2(ST, T, PWIDTH, KSIZE, [KERNEL])
% Returns the nonlinear Cross-Intensity kernel (definition 2).
% If more than two neurons are provided, V is the Gram matrix,
% otherwise it is a scalar.
%
%      ST: Data, organized in a cell array, with each cell containing an
%          array of spike times (sec).
%       T: Duration of the spike trains (sec).
%  PWIDTH: Duration of the rectangular pulse smoothing function for
%          intensity estimation (sec).
%   KSIZE: Bandwidth parameter of nonlinear kernel (spk/s).
%  KERNEL: [optional] String describing which kernel to use in the
%          evaluation of the inner product. Default: 'gaussian'.
%          Other known values are: 'laplacian', 'triangular', and 'rectwin'.
%
% This version provides a fast implementation of the nCI inner product kernel,
% using a rectangular smoothing function (not to be confused with a
% rectangular kernel). See my dissertation for an explanation.

% Copyright (c) Antonio Paiva
% Feb 2008
% (Based on the CIK.M function)

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
N = length(st);
if (N < 2)
	error('At least two spike trains are needed to operate');
end

if (exist('kern_str') ~= 1)
	kern_str = 'gaussian';
end
switch lower(kern_str)
case 'gaussian'
	kernel = @(z) exp(-(z.^2) ./ (2*(ksize^2)));
case 'laplacian'
	kernel = @(z) exp(-abs(z) ./ ksize);
case 'triangular'
	kernel = @(z) ((abs(z) < ksize) .* (1 - abs(z)/ksize));
case 'rectwin'
	kernel = @(z) (abs(z) <= ksize);
otherwise
	error('Unknown kernel! Try one: ''laplacian'', ''gaussian'', ''triangular'' and ''rectwin''');
end

% ensure each spike train is a row vector, and 
% find the number of spikes in each spike train
L = zeros(1,N);
for i = 1:N
	if (~isempty(st{i}))
		st{i} = st{i}(:)';
	end
	L(i) = length(st{i});
end

V = zeros(N);
for i = 1:(N-1)
	for j = i:N
		if ((L(i) > 0) && (L(j) > 0))
			% auxiliary sets
			% times: when the difference between intensity functions changes
			[times idx] = sort([0, st{i}-pwidth/2, st{i}+pwidth/2, ...
								   st{j}-pwidth/2, st{j}+pwidth/2]);
			% if the difference should increase or decrease
			incr = [0, ones(1,L(i)), -ones(1,L(i)), ...
					  -ones(1,L(j)),  ones(1,L(j))];
			incr = incr(idx);

			% evaluate inner prod
			val = cumsum(incr) ./ pwidth;
			times(times < 0) = 0;
			times(times > T) = T;
			dtimes = diff([times T]);
			nzidx = (dtimes ~= 0);
			V(i,j) = sum(dtimes(nzidx) .* kernel(val(nzidx)));
		end
	end
end
if (N == 2)
	V = V(1,2);
else
	V = V + V' - diag(diag(V));
end

% vim: ts=4
