function plot_spk_trains(x, T, lsize)
%plot_spk_trains(X, T, [lsize])
% Plot spike trains, as lines.
%
%     X: Cell array with one cell per neuron,
%        with the spike times (in seconds).
%     T: Time length (or interval) of the data to be plotted (in sec),
% lsize: [optional] Size of the line per spike, value [0.1:1]
%        (default: 0.9)

% ---------------------------------------------------------
% check input

if (min(size(x))>1)
	error('X must be an array of cells or spike times!');
end
if (~iscell(x))
	a{1} = x;
	x = a;
	clear a
end

N = length(x);
for i = 1:N
	[a b] = size(x{i});
	if (min([a b]) > 1)
		error('Each entry of the cell must be an a vector!')
	end
	if (a > b)	% make x{i} a row vector
		x{i} = x{i}';
	end
end

if (length(T) == 1)
	T(2) = T(1);
	T(1) = 0;
end

if (nargin < 3)
	lsize = 0.9;
end

if (~isscalar(lsize))
	error('lsize must be a scalar!');
elseif ((lsize < 0.1) || (lsize > 1))
	error('lsize must be in the [0.1:1] interval!');
end

% ---------------------------------------------------------
% plot and write axis labels
%

for i = 1:N
	idx = find((x{i}(:) >= T(1)) & (x{i}(:) <= T(2)));
	plot([x{i}(idx); x{i}(idx)], repmat(i+[-lsize; lsize]./2,1,length(idx)),'k');
	hold on
end
xlabel('Time (s)');
axis([T(1) T(2) 0.5 N+0.5]);
hold off

% for i = 1:N
% 	if (min(size(x{i})) > 1)
% 		warning(sprintf('X{%d} is not an *array* of spike times!',i));
% 	end
% 	idx = find(x{i}(:) < T);
% 	plot([x{i}(idx); x{i}(idx)], ...
% 		[(N-i)*ones(1,length(idx))+(1-lsize)/2; (N-i+1)*ones(1,length(idx))-(1-lsize)/2],'k');
% 	hold on
% end
% xlabel('Time (s)');
% str = num2str(N);
% for i = N-1:-1:1
% 	str = [str '|' num2str(i)];
% end
% axis([0 T 0 N]);
% set(gca,'YTick', 0.5:1:(N-0.5));
% set(gca,'YTickLabel', str);
% hold off
