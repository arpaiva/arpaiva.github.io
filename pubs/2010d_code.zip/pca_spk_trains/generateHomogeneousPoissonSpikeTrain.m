function st = generateHomogeneousPoissonSpikeTrain(firingRate, lengthSec)
% st = generateHomogeneousPoissonSpikeTrain(firingRate, lengthSec)
% Generate a homogeneous Poisson spike train with firingRate and lengthSec
% Exponential distribution of interspike interval is used.
%
% Input:
%   firingRate	the firing rate \lambda
%   lengthSec	length of the spike train to be generated
%
% Copyright 2005-2006 Memming. All rights reserved.
% $Id: generateHomogeneousPoissonSpikeTrain.m 12 2006-10-11 21:56:52Z memming $

st = zeros(1, ceil(firingRate * lengthSec * 2)); % fast allocation

k = 1;
st(k) = -log(rand) / firingRate;
if st(k) > lengthSec
    st = []; % no spike at all
    return;
end

while true
    k = k + 1;
    delta = -log(rand) / firingRate;
    st(k) = st(k - 1) + delta;
    if st(k) > lengthSec
		st = st(1:k-1);
		break;
    end
end

