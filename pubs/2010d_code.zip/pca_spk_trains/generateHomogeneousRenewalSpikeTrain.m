function st = generateHomogeneousRenewalSpikeTrain(rate, lengthSec, distrib, shapeParam)
% st = generateHomogeneousRenewalSpikeTrain(
%                rate, lengthSec, distrib, shapeParam)
% Generate a spike train as a realization of an homogeneous renewal
% point process with rate events per second and lengthSec.
% distrib control the distribution of the interspike intervals.
%
% Input:
%   rate        average rate of events per second
%   lengthSec   length of the spike train to be generated
%   distrib     [optional] distribution of the ISIs:
%               'gamma' (default) or 'lognormal'.
%   shapeParam  [optional] shape parameter for the distribution of the ISIs.
%               If this argument is ommited, the distributions take default
%               values: k = 2 for the gamma, and std = 0.5 for the lognormal.
%               (The second parameter of the distributions is adjusted to
%                obtain the desired rate of events.)

% Copyright 2008 Antonio Paiva. All rights reserved.
% (Modified from code by Memming.)
% Jan 2008

if (exist('distrib') ~= 1)
	distrib = 'gamma';
end
if (exist('shapeParam') ~= 1)
	switch lower(distrib)
	case 'gamma'
		shapeParam = 2;
	case 'lognormal'
		shapeParam = 0.5;
	end
end

switch lower(distrib)
case 'gamma'
	%rndsample = @(n) gamrnd(shapeParam, 1/(shapeParam*rate), n,1);
	rndsample = @(n) rgamma(n, shapeParam) ./ (shapeParam*rate);
case 'lognormal'
	rndsample = @(n) lognrnd(log(1/rate) - (shapeParam^2)/2, shapeParam, n,1);
end

st = zeros(1, ceil(rate * lengthSec * 2)); % fast allocation

k = 1;
st(k) = rndsample(1);
if st(k) > lengthSec
    st = []; % no spike at all
    return;
end

while true
    k = k + 1;
    st(k) = st(k - 1) + rndsample(1);
    if st(k) > lengthSec
		st = st(1:k-1);
		break;
    end
end

