%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Clustering of spike trains by distribution of the ISIs.
%
% DATASET GENERATION:
% Spike trains were generated as an homogeneous Renewal point process,
% with a Lognormal ISI distribution.
%
% Antonio Paiva
% Apr 2008
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear; close all
rand('seed', 20080309);
randn('seed',20080309);

%% settings
%=====================================================================

distrib = 'gamma';
distrib_param = [0.5 1 3];
Nc = length(distrib_param);	% number of clusters
M = 100;				% number of test spike trains
MC = 500;				% Monte Carlo runs
T = 1;					% length of each spike train (sec)
dt = 1E-3;				% fr sampling period
smooth = [2 10 100].*1E-3;	% width/bin size for smoothing function
smooth_func = 'gaussian';	% smoothing function
ksize = [0.1 1 10];		% Gaussian kernel size for nCIk2
rate = 20;

%% run simulation
%=====================================================================

res_mcik = zeros(MC,length(smooth));
res_ncik = zeros(MC,length(smooth),length(ksize));
surrogate = zeros(1,MC);

tic
for m = 1:MC
	fprintf('MC %d/%d: ETA %.1fs...\n',m,MC, (MC-m+1)*toc); tic

	% generate random assignment of clusters
	cluster_labels = ceil(Nc * rand(1,M));

	% generate spike trains
	st = cell(M,1);
	for i = 1:M
		while (1)
			st{i} = generateHomogeneousRenewalSpikeTrain(rate, T, ...
						distrib, distrib_param(cluster_labels(i)));
			if (length(st{i}) > 0)
				break;
			end
		end
	end

	for s = 1:length(smooth)
		% mCI kernel
		%---------------------------------
		
		% affinity matrix
 		aux = mcik(st, smooth(s), smooth_func);
		A = zeros(M);
		b = 1;
		for i = 1:M
			for j = (i+1):M
				A(i,j) = aux(b);
				b = b+1;
			end
		end
		A = A + A';
		% spectral clustering
		idx = spectral_clustering(A, Nc, 10);
		% evaluate clustering
		res_mcik(m,s) = eval_clustering(idx, cluster_labels);

		% nCI kernel (def.2)
		%---------------------------------
		for k = 1:length(ksize)
			fprintf(' + %d/%d    \r', (s-1)*length(ksize)+k, ...
				length(smooth)*length(ksize));

			% affinity matrix
 	 		A = ncik2(st, T, smooth(s), ksize(k));
			% spectral clustering
			idx = spectral_clustering(A, Nc, 10);
			% evaluate clustering
			res_ncik(m,s,k) = eval_clustering(idx, cluster_labels) * 100/M;
		end
	end
	surrogate(m) = eval_clustering(ceil(Nc*rand(size(cluster_labels))), ...
															cluster_labels);
end
stat_mcik.avg = mean(res_mcik);
stat_mcik.stddev = std(res_mcik);
stat_ncik.avg = squeeze(mean(res_ncik));
stat_ncik.stddev = squeeze(std(res_ncik));
surrogate_dev = std(surrogate);
surrogate = mean(surrogate);

fn = sprintf('results/result_%s_Nc%d_Nst%03d_MC%03d_%s.mat', ...
	distrib, Nc, M, MC, smooth_func);
save(fn,'res_mcik','res_ncik','distrib','distrib_param','Nc','M','MC', ...
	'T','dt','smooth','smooth_func','ksize','rate','stat_mcik','stat_ncik',...
	'surrogate','surrogate_dev')

%% illustration figs
%=====================================================================

figure(1)
mark = {'s','x','o'};
L = length(distrib_param);
x = [0 : (4/rate)/100 : 4/rate];
str = {};
for i = 1:length(distrib_param)
	if strcmp(distrib,'lognormal')
		plot(x, lognpdf(x, log(1/rate) - (distrib_param(i)^2)/2, ...
			distrib_param(i)), [mark{i} '-'], 'Markersize',5);
		str{end+1} = ['\sigma = ', num2str(distrib_param(i))];
	else
		plot(x, gampdf(x, distrib_param(i), 1/(distrib_param(i)*rate)), ...
			[mark{i} '-'], 'Markersize',5);
		str{end+1} = ['\theta = ', num2str(distrib_param(i))];
	end
	hold all
end
% plot(x, exppdf(x,1/rate), 'g--');
set(gca, 'FontSize',14);
legend(str), xlabel('ISI (s)'), ylabel('ISI distribution');
set(gcf, 'PaperUnits','inches', 'PaperPosition',[0, 0, 6, 3]);
saveas(1, sprintf('figs/fig_%s_Nc%d_pdf',distrib,Nc), 'epsc2');
saveas(1, sprintf('figs/fig_%s_Nc%d_pdf',distrib,Nc), 'png');

figure(2)
st = cell(1,length(distrib_param));
for i = 1:length(distrib_param)
	if strcmp(distrib,'lognormal')
		st{i} = generateHomogeneousRenewalSpikeTrain(rate, 2, ...
				'lognormal', distrib_param(i));
	else
		st{i} = generateHomogeneousRenewalSpikeTrain(rate, 2, ...
				'gamma', distrib_param(i));
	end
end
set(gca, 'FontSize',14);
plot_spk_trains(st, 2);
set(gca,'Ytick',[1:length(distrib_param)], ...
	'Yticklabel',num2str(distrib_param'));
set(gcf, 'PaperUnits','inches', 'PaperPosition',[0, 0, 6, 2]);
saveas(2, sprintf('figs/fig_%s_Nc%d_st',distrib,Nc), 'epsc2');
saveas(2, sprintf('figs/fig_%s_Nc%d_st',distrib,Nc), 'png');
clear st

%% plot clustering results
%=====================================================================

load(sprintf('results/result_%s_Nc%d_Nst%03d_MC%03d_%s.mat', ...
	distrib, Nc, M, MC, smooth_func));

figure(3)
mark = {'s','x','o'};
L = length(distrib_param);
color = get(gca, 'ColorOrder');

% mCIk results
errorbar([1:length(smooth)], mean(res_mcik),std(res_mcik), '+--', ...
	'Linewidth',1.5);
hold all

% nCIk2 results
str = {'mCI kernel'};
for j = 2:length(ksize)
	errorbar([1:length(smooth)], stat_ncik.avg(:,j), stat_ncik.stddev(:,j), ...
		[mark{j} '-'], 'Color',color(j,:), 'Linewidth',1.5);
	hold on
	str{end+1} = sprintf('nCI kernel (\\sigma=%.1f)', ksize(j));
end

% surrogate results
ax = axis;
plot([ax(1) ax(2)], mean(surrogate)*[1 1], 'k:', 'Linewidth',1);
str{end+1} = 'random selection';

set(gca, 'FontSize',14);
xlabel('smoothing width (ms)'); ylabel('% correct clustering');
set(gca, 'Xtick',[1:length(smooth)], ...
	'XtickLabel',num2str(round(smooth'/1E-3)));
legend(str, 'Location','NorthWest');
drawnow;

%set(gcf, 'PaperUnits','inches', 'PaperPosition',[0, 0, 8, 7]);
saveas(3, sprintf('figs/fig_%s_Nc%d_results',distrib,Nc),'epsc2');
saveas(3, sprintf('figs/fig_%s_Nc%d_results',distrib,Nc),'png');
