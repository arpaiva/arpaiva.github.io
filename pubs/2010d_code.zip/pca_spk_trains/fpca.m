function pca = fpca(stCell, kernel)
% functional PCA (or kernel PCA) of spike trains
% Input:
%   stCell: (1xN) cell array of spike train arrays
%   kernel: (function handle st x st -> R) kernel
%
% Output:
%   pca: a structure of all info for projection
%	pca.Itilde: the matrix for eigenvalue problem
%	pca.stCell: stCell
%	pca.kernel: kernel function handle
%	pca.N: N
%	pca.rho: (Nx1) eigenvalues in descending order
%	pca.b: (NxN) corresponding eigenvectors (N column vectors)
%
% See also: project2PCA, ex0
%
% $Id: fpca.m 230 2007-05-24 19:30:10Z arpaiva $
% Copyright 2007 Antonio and Memming, CNEL, all rights reserved.

N = length(stCell);
if N < 2; error('At least two spike trains are needed'); end

I = zeros(N, N);
for k = 1:N
    for kk = 1:N
	I(k, kk) = kernel(stCell{k}, stCell{kk});
    end
end

pca.I = I;
pca.Itilde = I - (ones(N, N) * I + I * ones(N, N)) ./ N ...
    + ones(1, N) * I * ones(N, 1) ./ (N^2);

pca.N = N;
pca.kernel = kernel;
pca.stCell = stCell;
[b rho] = eig(pca.Itilde);
rho = diag(rho);
[pca.rho, idx] = sort(rho, 'descend');
pca.b = b(:,idx) * diag(sqrt(pca.rho));

% vim: set ts=8 sts=4 sw=4: (modeline)
