/**
 * @author Antonio Paiva
 * @version $Id: mcik.c ## 2007-08-16 17:00:00Z arpaiva $
 * Jul 2007
 */

/* vim: set ts=8 sts=4 sw=4: (modeline) */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mex.h>

#define LAPLACIAN	0
#define GAUSSIAN	1
#define TRIANGULAR	2
#define RECTWIN		3

void mcik_func(int N, double *x[], int nSpikes[], int kernel,
				double ksize, double *v);

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
    mxArray *sts;
    mxArray *stp;
    int nSpikeTrains;    /* number of spike trains */
    double **x;			/* array of vectors with the
						 * spike times (sec) */ 
    int *nSpikes;		/* array with the number of spikes
						 * per spike train */
    double ksize;		/* kernel size */
    double *v;			/* output argument, mCIk */
	char kern_str[64];	/* string name of the kernel function to use */
	int kernel;			/* numeric index of the kernel function to use */
    int i;

    /*
     * check input arguments
     */

    if (nrhs < 2) {
		mexErrMsgTxt("At least two inputs are required.");
    } else if (nlhs > 1) {
		mexErrMsgTxt("Too many output arguments");
    } else if (!mxIsDouble(prhs[1]))
		mexErrMsgTxt("KERNEL_SIZE must be a scalar");

	/* process optional argument (kernel) */
	if (nrhs > 2) {
    	if (!mxIsChar(prhs[2])) {
			mexErrMsgTxt("KERNEL must be a string");
		}
		mxGetString((mxArray *) prhs[2], kern_str, 64);
		if (strncmp(kern_str, "laplacian", 10) == 0) {
			kernel = LAPLACIAN;
		} else if (strncmp(kern_str, "gaussian", 9) == 0) {
			kernel = GAUSSIAN;
		} else if (strncmp(kern_str, "triangular", 11) == 0) {
			kernel = TRIANGULAR;
		} else if (strncmp(kern_str, "rectwin", 8) == 0) {
			kernel = RECTWIN;
		} else {
			mexErrMsgTxt("Unknown kernel! Try one: 'laplacian',"
						 "'gaussian', 'triangular' and 'rectwin'");
		}
	}
	else
		kernel = LAPLACIAN;

    /*
     * get input arguments
     */

    sts = (mxArray *) prhs[0];
    if (mxGetClassID(sts) != mxCELL_CLASS) {
		mexErrMsgTxt("X must be a cell array");
    }

    nSpikeTrains = mxGetNumberOfElements(sts);

    if (nSpikeTrains < 2) {
		mexErrMsgTxt("At least two spike trains are needed.");
    }

    nSpikes = (int *) mxMalloc(sizeof(int) * nSpikeTrains);
    x = (double **) mxMalloc(sizeof(double*) * nSpikeTrains);

    for (i = 0; i < nSpikeTrains; i++) {
		stp = mxGetCell(sts, i);
		nSpikes[i] = mxGetNumberOfElements(stp);
		x[i] = mxGetPr(stp);
    }

    ksize = mxGetPr(prhs[1])[0];	/* kernel size */

    /*
     * allocate output
     */

    plhs[0] = mxCreateDoubleMatrix(nSpikeTrains*(nSpikeTrains-1)/2, 1, mxREAL);
    v = mxGetPr(plhs[0]);
    memset(v, 0, (nSpikeTrains*(nSpikeTrains-1)/2) * sizeof(double));

    /*
     * compute mCI kernel
     */
    mcik_func(nSpikeTrains, x, nSpikes, kernel, ksize, v);
}

/**
 * Compute the memoryless Cross-Intensity kernel of a set of spike trains.
 *
 * @param N number of spike trains
 * @param x array to pointers for spike trains
 * @param nSpikes array to length for spike trains
 * @param kernel index to kernel function to be used in the computation
 * @param ksize kernel size parameter
 * @param v computed mCIk will be stored here, need to be preallocated
 * @author Antonio Paiva
 */
void mcik_func(
	int N, double *x[], int nSpikes[], int kernel, double ksize, /* INPUT */
	double *v) /* for OUTPUT */
{
	int k;		/* index of the output vector to store mCIk */
    int i, j;	/* counters for spike trains */
    int m, n;	/* counters for spike times */
    int lastStartIdx; /* index to start computing the exponential */
    double aux;	/* auxiliary variable: holds mCIk for each
				 * pair combination */
    double tmp;

	if (kernel == LAPLACIAN) {
    	double maxT;/* maximum range of kernel to have non-zero value */
		k = 0;
    	maxT = ksize * 100;
    	for (i=0; i<(N-1); i++) {
		for (j=(i+1); j<N; j++) {
	    	aux = 0;
	    	lastStartIdx = 0;
		    for (m=0; m<nSpikes[i]; m++) {
			for (n=lastStartIdx; n<nSpikes[j]; n++) {
			    tmp = x[j][n] - x[i][m];
			    if (tmp < -maxT) {
					lastStartIdx = n;
				}
			    if (tmp <= maxT) {
					aux += exp(-((tmp < 0) ? (-tmp) : tmp) / ksize);
			    } else {
					break;
			    }
			}
		    }
		    v[k++] = aux / (2 * ksize);
		}
		}
	} else if (kernel == GAUSSIAN) {
    	double maxT;/* maximum range of kernel to have non-zero value */
		k = 0;
    	maxT = ksize * 100;
    	for (i=0; i<(N-1); i++) {
		for (j=(i+1); j<N; j++) {
			double eDen = 1 / (2 * pow(ksize,2));
								/* denominator of argument of exponential */
	    	aux = 0;
	    	lastStartIdx = 0;
		    for (m=0; m<nSpikes[i]; m++) {
			for (n=lastStartIdx; n<nSpikes[j]; n++) {
			    tmp = x[j][n] - x[i][m];
			    if (tmp < -maxT) {
					lastStartIdx = n;
				}
			    if (tmp <= maxT) {
					aux += exp(-pow(tmp,2) * eDen);
			    } else {
					break;
			    }
			}
		    }
		    v[k++] = aux / (sqrt(2 * M_PI) * ksize);
		}
		}
	} else if (kernel == TRIANGULAR) {
		double ksize2;
		k = 0;
		ksize2 = 2 * ksize;
    	for (i=0; i<(N-1); i++) {
		for (j=(i+1); j<N; j++) {
	    	aux = 0;
	    	lastStartIdx = 0;
		    for (m=0; m<nSpikes[i]; m++) {
			for (n=lastStartIdx; n<nSpikes[j]; n++) {
			    tmp = x[j][n] - x[i][m];
			    if (tmp < -ksize2) {
					lastStartIdx = n;
				} else if (tmp > ksize2) {
					break;
			    }
				tmp = ((tmp < 0) ? (-tmp) : tmp);
			    if (tmp < ksize2) {
					aux += 1 - (tmp / ksize2);
			    }
			}
		    }
		    v[k++] = aux / (2 * ksize);
		}
		}
	} else if (kernel == RECTWIN) {
		k = 0;
    	for (i=0; i<(N-1); i++) {
		for (j=(i+1); j<N; j++) {
	    	aux = 0;
	    	lastStartIdx = 0;
		    for (m=0; m<nSpikes[i]; m++) {
			for (n=lastStartIdx; n<nSpikes[j]; n++) {
			    tmp = x[j][n] - x[i][m];
			    if (tmp < -ksize) {
					lastStartIdx = n;
				} else if (tmp > ksize) {
					break;
			    }
				tmp = ((tmp < 0) ? (-tmp) : tmp);
			    if (tmp < ksize) {
					aux += 1;
			    }
			}
		    }
		    v[k++] = aux / (2 * ksize);
		}
		}
	}
}

