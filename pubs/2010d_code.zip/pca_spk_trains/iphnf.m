function V = ip_houghton(st, T, tau, gmax, nonlin_fn, smooth_fn)
%V = IP_HOUGHTON(ST, T, TAU, GMAX, [NONLIN_FN])
% Returns the spike train inner product defined using the membrane
% potential used by Houghton for the b-metric. If more than two neurons 
% are provided, V is the Gram matrix, otherwise it is a scalar.
%
% The inner product is defined as
%     V(s_i,s_j) = \int_0^T f(v(s_i,t)) f(v(s_j,t)) dt
% with v(s_i,t) = \sum_{m=1}^{N_i} h(t-t^i_m).
%
%         ST: Data, organized in a cell array, with each cell containing an
%             array of spike times (sec).
%          T: Duration of the spike trains (sec).
%        TAU: Width parameter of the smoothing function h (in sec).
%       GMAX: Scaling parameter of the membrane potential.
%  NONLIN_FN: [optional] Name of the f nonlinear function on the membrane
%             potential model. Known values are 'tanh' (default) and 'igauss'.
%  SMOOTH_FN: [optional] Name of the smoothing function.
%             Known values are: 'exp' (default), 'gaussian' and 'laplacian'.
%
% Note: For simplicity, h is normalized to have unit area. In this way,
%       v(s_i,t) has the same meaning as the estimated intensity function,
%       and GMAX is the maximum expected firing rate.

% Copyright (c) Antonio Paiva
% last revised: Jun 28, 2009

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
N = length(st);
if (N < 2)
	error('Need at least two neurons to operate');
end

if (nargin < 5) || isempty(nonlin_fn)
	nonlin_fn = 'tanh';
end
switch lower(nonlin_fn)
case 'tanh'
	f = @(x) gmax .* tanh(x ./ gmax);
case 'igauss'
	f = @(x) gmax .* (1 - exp(-(x.^2) ./ (2*(gmax^2))));
otherwise
	error('Unknown kernel! Known functions are ''tanh'' and ''igauss''');
end

if (nargin < 6) || isempty(smooth_fn)
	smooth_fn = 'exp';
end
switch lower(smooth_fn)
case 'exp'
	h = @(t, t0) (exp(-abs(t - t0) ./ tau) ./ tau) .* (t >= t0);
case 'gaussian'
	h = @(t, t0) exp(-(t - t0).^2 ./ (2*tau*tau)) ./ (2*pi*tau);
case 'laplacian'
	h = @(t, t0) exp(-abs(t - t0) ./ tau) ./ (2*tau);
otherwise
	error('Unknown smoothing function!\n Known smoothing functions are ''exp'', ''gaussian'' and ''laplacian''.');
end

% ensure each spike train is a row vector
L = zeros(1,N);
for i = 1:N
	[a b] = size(st{i});
	if (~isempty(st{i}))
		if (a > b)
			st{i} = st{i}(:,1)';
		else
			st{i} = st{i}(1,:);
		end
	end
	L(i) = length(st{i});
end

% compute smoothed spike trains
t = [0:(tau/10):T]';
S = zeros(length(t), N);
for i = 1:N
	for j = 1:L(i)
		S(:,i) = S(:,i) + h(t, st{i}(j));
	end
end
S = f(S);

% compute inner product/kernel matrix
V = zeros(N);
for i = 1:(N-1)
	for j = i:N
		if (L(i) > 0) && (L(j) > 0)
			% numerical evaluation of the integral
			V(i,j) = sum(S(:,i) .* S(:,j)) * (tau/10);
		end
	end
end
if (N == 2)
	V = V(1,2);
else
	V = V + V' - diag(diag(V));
end

% vim: ts=4
