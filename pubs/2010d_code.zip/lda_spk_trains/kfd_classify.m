function [z y Pe] = kfd_classify(fd, stCell, labels)
% Classifies a set of spike trains onto two classes.
%
% [z y Pe] = kfd_classify(fd, stCell, [labels]);
%
% Input:
%   fd: the structure obtained from kfd
%   stCell: (Mx1) cell array of spike trains to be classified
%   labels: [optional] (Mx1) array with true class labels
%           if this array is provided, the class calculates the prob error
%
% Output:
%   z: (Mx1) classification labels (0/1)
%   y: (Mx1) projection value (i.e., before threshold)
%   Pe: (Mx1) if labels is provided, the prob of error
%
% See also: kfd
%
% Copyright 2009 Antonio, SCI Institute, Univ. of Utah, all rights reserved.

M = length(stCell);

% compute projections
y = zeros(M,fd.N);
for i = 1:M
    st = stCell{i};
	yy = fd.kernel({st, fd.stCell{:}});
	y(i,:) = yy(1,2:end);
	% for j = 1:fd.N
	% 	y(i,j) = fd.kernel({st, fd.stCell{j}});
	% end
end
y = y * fd.w;

% classify spike trains
if (fd.b_mode == 1)
	z = (y >= fd.b);
else
	z = (y <= fd.b);
end

% compute prob error, Pe
if (nargin >= 3) && ~isempty(labels)
	lbl = sort(unique(labels),'ascend');
	if length(lbl) == 2;
		% transform labels to column vector with 0/1 format
		labels(labels == lbl(1)) = 0;
		labels(labels == lbl(2)) = 1;
		if (size(labels,2) > size(labels,1)), labels = labels(1,:)'; end
		% compute Pe
		Pe = mean(labels ~= z);
	end
else
	Pe = [];
end

% vim: set ts=4: (modeline)
