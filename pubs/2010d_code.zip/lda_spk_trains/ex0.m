%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification of spike trains from RENEWAL point processes,
% using Kernel Fisher Linear Discriminant.
%
% DATASET GENERATION:
% Spike trains were generated as homogeneous renewal point processes,
% with either a lognormal or gamma ISI distribution.
%
% Antonio Paiva
% Jun 29, 2009
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear; close all
rand ('state',20090629);
randn('state',20090629);

%% settings
%=====================================================================

nTrainSpikeTrains = 50;
nTestSpikeTrains = 200;

% mCI
kfunc = 'laplacian';	% kernel to use in the mCI kernel estimator
ksize = 50E-3;			% width/bin size/kernel for smoothing function
						% and kernel size for mCI estimator
% IP Houghton 
smooth_fn = 'exp';		% smoothing function (tau = ksize)

% parameters for renewal point processes
distrib = 'gamma';
distrib_param = [0.5 3];
T = 1;					% length of each spike train (sec)
rate = 20;

%% generate spike trains
%=====================================================================

% generate training data
stSetTrain = cell(1,nTrainSpikeTrains);
for i = 1:2
	for j = 1:nTrainSpikeTrains/2
		idx = (i-1)*(nTrainSpikeTrains/2) + j;
		while (1)
			stSetTrain{idx} = generateHomogeneousRenewalSpikeTrain(...
									rate, T, distrib, distrib_param(i));
			if (~isempty(stSetTrain{idx})), break; end
		end
	end
end
stSetTrain1 = stSetTrain(1:nTrainSpikeTrains/2);
stSetTrain2 = stSetTrain(nTrainSpikeTrains/2+1:end);
labelsTrain = [zeros(1,nTrainSpikeTrains/2), ones(1,nTrainSpikeTrains/2)];

% generate test data
stSetTest = cell(1,nTestSpikeTrains);
for i = 1:2
	for j = 1:nTestSpikeTrains/2
		idx = (i-1)*(nTestSpikeTrains/2) + j;
		while (1)
			stSetTest{idx} = generateHomogeneousRenewalSpikeTrain(...
									rate, T, distrib, distrib_param(i));
			if (~isempty(stSetTest{idx})), break; end
		end
	end
end
stSetTest1 = stSetTest(1:nTestSpikeTrains/2);
stSetTest2 = stSetTest(nTestSpikeTrains/2+1:end);
labelsTest = [zeros(1,nTestSpikeTrains/2), ones(1,nTestSpikeTrains/2)];

% plot spike trains
figure;
h = (nTestSpikeTrains / (nTrainSpikeTrains + nTestSpikeTrains)) * 0.8;
ax = axes('position', [0.13 (0.1 + h + 0.05) 0.85 (0.8 - h)]);
set(gca, 'FontSize',14);
plot_spk_trains(stSetTrain, T, 1);
set(gca, 'Xtick', []); xlabel('');
ylabel('training')
ax = axes('position', [0.13 0.1 0.85 h]);
set(gca, 'FontSize',14);
plot_spk_trains([stSetTest1, stSetTest2], T, 1);
ylabel('testing'), xlabel('time (s)');
%
ax = axes('position', [0 0.95 0.05 0.05]);
set(gca, 'Visible','off');
text(0, 0, 'A', 'HorizontalAlignment','left', ...
	'FontSize', 16, 'FontWeight', 'bold');
ax = axes('position', [0 (0.1 + h) 0.05 0.05]);
set(gca, 'Visible','off');
text(0, 0, 'B', 'HorizontalAlignment','left', ...
	'FontSize', 16, 'FontWeight', 'bold');
% saveas(gcf, 'figs/fig_kfd_spkTrains.png','png');
% saveas(gcf, 'figs/fig_kfd_spkTrains.eps','eps2');

% %% compute KFD with mCI kernel
% %=====================================================================
% 
% mcik_handler = @(st) fh_mcik(st, ksize, kfunc);
% 
% % compute KFLDA parameters: projection vector and threshold
% fd = kfd(stSetTrain, labelsTrain, mcik_handler);
% fprintf('%.3f%% error in training set...\n', 100*fd.Pe);
% 
% % classify the test data
% [z y Pe] = kfd_classify(fd, stSetTest, labelsTest);
% fprintf('%.3f%% error in testing set...\n', 100*Pe);
% 
% g = exp(- [-4:4].^2 / 8); g = g ./ sum(g);
% % % projected training data
% % figure;
% % [h x] = hist(fd.y(labelsTrain==0),10); h = conv(g,h); h = h(5:end-4); h = h ./ sum(h);
% % plot(x, h, 'b-', 'LineWidth',2), hold on;
% % plot(fd.y(labelsTrain==0), 0, 'ob');
% % [h x] = hist(fd.y(labelsTrain==1),10); h = conv(g,h); h = h(5:end-4); h = h ./ sum(h);
% % plot(x, h, '--', 'Color',[0 0.8 0], 'LineWidth',2)
% % plot(fd.y(labelsTrain==1), 0, 'sr');
% % xlabel('projection','FontSize',16), ylabel('distribution','FontSize',16)
% % % saveas(gcf, 'figs/fig_kfd_mCI_projTrain.png','png');
% % % saveas(gcf, 'figs/fig_kfd_mCI_projTrain.eps','epsc2');
% 
% % projected testing data
% figure;
% [h x] = hist(y(labelsTest==0),20); h = conv(g,h); h = h(5:end-4);
% h = h ./ (sum(h) * mean(diff(x)));
% plot(x, h, 'b-', 'LineWidth',2), hold on;
% plot(y(labelsTest==0), 0, 'ob', 'LineWidth',1.5);
% [h x] = hist(y(labelsTest==1),20); h = conv(g,h); h = h(5:end-4);
% h = h ./ (sum(h) * mean(diff(x)));
% plot(x, h, '--', 'Color',[0 0.8 0], 'LineWidth',2)
% plot(y(labelsTest==1), 0, 'x', 'LineWidth',1.5, 'Color',[0 0.8 0]);
% xlabel('projection','FontSize',16), ylabel('distribution','FontSize',16)
% saveas(gcf, 'figs/fig_kfd_mCI_projTest.png','png');
% saveas(gcf, 'figs/fig_kfd_mCI_projTest.eps','epsc2');
% 
% %% compute KFD with nCI
% %=====================================================================
% 
% nci_handler = @(st) ncik2(st, T, 50E-3, 1);
% 
% % compute KFD parameters: projection vector and threshold
% fd = kfd(stSetTrain, labelsTrain, nci_handler);
% fprintf('%.3f%% error in training set...\n', 100*fd.Pe);
% 
% % classify the test data
% [z y Pe] = kfd_classify(fd, stSetTest, labelsTest);
% fprintf('%.3f%% error in testing set...\n', 100*Pe);
% 
% g = exp(- [-4:4].^2 / 8); g = g ./ sum(g);
% % % projected training data
% % figure;
% % [h x] = hist(fd.y(labelsTrain==0),10); h = conv(g,h); h = h(5:end-4); h = h ./ sum(h);
% % plot(x, h, 'b-', 'LineWidth',2), hold on;
% % plot(fd.y(labelsTrain==0), 0, 'ob');
% % [h x] = hist(fd.y(labelsTrain==1),10); h = conv(g,h); h = h(5:end-4); h = h ./ sum(h);
% % plot(x, h, '--', 'Color',[0 0.8 0], 'LineWidth',2)
% % plot(fd.y(labelsTrain==1), 0, 'sr');
% % xlabel('projection','FontSize',16), ylabel('distribution','FontSize',16)
% % % saveas(gcf, 'figs/fig_kfd_nCI_projTrain.png','png');
% % % saveas(gcf, 'figs/fig_kfd_nCI_projTrain.eps','epsc2');
% 
% % projected testing data
% figure;
% [h x] = hist(y(labelsTest==0),20); h = conv(g,h); h = h(5:end-4);
% h = h ./ (sum(h) * mean(diff(x)));
% plot(x, h, 'b-', 'LineWidth',2), hold on;
% plot(y(labelsTest==0), 0, 'ob', 'LineWidth',1.5);
% [h x] = hist(y(labelsTest==1),20); h = conv(g,h); h = h(5:end-4);
% h = h ./ (sum(h) * mean(diff(x)));
% plot(x, h, '--', 'Color',[0 0.8 0], 'LineWidth',2)
% plot(y(labelsTest==1), 0, 'x', 'LineWidth',1.5, 'Color',[0 0.8 0]);
% xlabel('projection','FontSize',16), ylabel('distribution','FontSize',16)
% saveas(gcf, 'figs/fig_kfd_nCI_projTest.png','png');
% saveas(gcf, 'figs/fig_kfd_nCI_projTest.eps','epsc2');

%% compute PCA with IP_Hougton (inner product corresponding to the b-metric)
%=====================================================================

mu = [0.1:0.1:0.9];
for k = 1:length(mu)
	fprintf('*** IPH: mu = %.2f\n', mu(k));

	iph_handler = @(st) iph1(st, T, ksize, mu(k));

	% compute KFD parameters: projection vector and threshold
	fd = kfd(stSetTrain, labelsTrain, iph_handler);
	fprintf('%.3f%% error in training set...\n', 100*fd.Pe);

	% classify the test data
	tic
	[z y Pe] = kfd_classify(fd, stSetTest, labelsTest);
	toc
	fprintf('%.3f%% error in testing set...\n', 100*Pe);

	g = exp(- [-4:4].^2 / 8); g = g ./ sum(g);
	% % projected training data
	% figure;
	% [h x] = hist(fd.y(labelsTrain==0),10); h = conv(g,h); h = h(5:end-4); h = h ./ sum(h);
	% plot(x, h, 'b-', 'LineWidth',2), hold on;
	% plot(fd.y(labelsTrain==0), 0, 'ob', ...
	% 	'MarkerSize',6,'LineWidth',2,'MarkerFaceColor','g')
	% [h x] = hist(fd.y(labelsTrain==1),10); h = conv(g,h); h = h(5:end-4); h = h ./ sum(h);
	% plot(x, h, '--', 'Color',[0 0.8 0], 'LineWidth',2)
	% plot(fd.y(labelsTrain==1), 0, 'sr', ...
	% 	'MarkerSize',5,'LineWidth',2,'MarkerFaceColor','y')
	% xlabel('projection','FontSize',16), ylabel('distribution','FontSize',16)
	% % saveas(gcf, 'figs/fig_kfd_iph1_projTrain.png','png');
	% % saveas(gcf, 'figs/fig_kfd_iph1_projTrain.eps','epsc2');
	
	% projected testing data
	figure;
	[h x] = hist(y(labelsTest==0),20); h = conv(g,h); h = h(5:end-4);
	h = h ./ (sum(h) * mean(diff(x)));
	plot(x, h, 'b-', 'LineWidth',2), hold on;
	plot(y(labelsTest==0), 0, 'ob', 'LineWidth',1.5);
	[h x] = hist(y(labelsTest==1),20); h = conv(g,h); h = h(5:end-4);
	h = h ./ (sum(h) * mean(diff(x)));
	plot(x, h, '--', 'Color',[0 0.8 0], 'LineWidth',2)
	plot(y(labelsTest==1), 0, 'x', 'LineWidth',1.5, 'Color',[0 0.8 0]);
	xlabel('projection','FontSize',16), ylabel('distribution','FontSize',16)
	gs = sprintf('_mu%02d', round(10*mu(k)));
	saveas(gcf, ['figs/fig_kfd_iph1_projTest' gs], 'png');
	saveas(gcf, ['figs/fig_kfd_iph1_projTest' gs], 'epsc2');
end

% %% compute KFD with IP_Houghton
% %  (using nonlinear approximation; see book chapter edited by Karim Oweiss)
% %=====================================================================
% 
% gmax = [1 2 3 5 10 20 40];
% for k = 1:length(gmax)
% 	fprintf('*** gmax = %d\n', gmax(k));
% 
% 	iph_handler = @(st) iphnf(st, T, ksize, gmax(k), 'tanh', 'exp');
% 
% 	% compute KFD parameters: projection vector and threshold
% 	fd = kfd(stSetTrain, labelsTrain, iph_handler);
% 	fprintf('%.3f%% error in training set...\n', 100*fd.Pe);
% 
% 	% classify the test data
% 	tic
% 	[z y Pe] = kfd_classify(fd, stSetTest, labelsTest);
% 	toc
% 	fprintf('%.3f%% error in testing set...\n', 100*Pe);
% 
% 	g = exp(- [-4:4].^2 / 8); g = g ./ sum(g);
% 	% % projected training data
% 	% figure;
% 	% [h x] = hist(fd.y(labelsTrain==0),10); h = conv(g,h); h = h(5:end-4); h = h ./ sum(h);
% 	% plot(x, h, 'b-', 'LineWidth',2), hold on;
% 	% plot(fd.y(labelsTrain==0), 0, 'ob', ...
% 	% 	'MarkerSize',6,'LineWidth',2,'MarkerFaceColor','g')
% 	% [h x] = hist(fd.y(labelsTrain==1),10); h = conv(g,h); h = h(5:end-4); h = h ./ sum(h);
% 	% plot(x, h, '--', 'Color',[0 0.8 0], 'LineWidth',2)
% 	% plot(fd.y(labelsTrain==1), 0, 'sr', ...
% 	% 	'MarkerSize',5,'LineWidth',2,'MarkerFaceColor','y')
% 	% xlabel('projection','FontSize',16), ylabel('distribution','FontSize',16)
% 	% % saveas(gcf, 'figs/fig_kfd_iphnf_projTrain.png','png');
% 	% % saveas(gcf, 'figs/fig_kfd_iphnf_projTrain.eps','epsc2');
% 	
% 	% projected testing data
% 	figure;
% 	[h x] = hist(y(labelsTest==0),20); h = conv(g,h); h = h(5:end-4);
% 	h = h ./ (sum(h) * mean(diff(x)));
% 	plot(x, h, 'b-', 'LineWidth',2), hold on;
% 	plot(y(labelsTest==0), 0, 'ob', 'LineWidth',1.5);
% 	[h x] = hist(y(labelsTest==1),20); h = conv(g,h); h = h(5:end-4);
% 	h = h ./ (sum(h) * mean(diff(x)));
% 	plot(x, h, '--', 'Color',[0 0.8 0], 'LineWidth',2)
% 	plot(y(labelsTest==1), 0, 'x', 'LineWidth',1.5, 'Color',[0 0.8 0]);
% 	xlabel('projection','FontSize',16), ylabel('distribution','FontSize',16)
% 	gs = sprintf('_gmax%02d', gmax(k));
% 	saveas(gcf, ['figs/fig_kfd_iphnf_projTest' gs], 'png');
% 	saveas(gcf, ['figs/fig_kfd_iphnf_projTest' gs], 'epsc2');
% end

