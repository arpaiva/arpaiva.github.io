function I = fh_mcik(st, ksize, kern_str)

N = length(st);
I = zeros(N);
if (nargin == 2) || isempty(kern_str)
	for i = 1:N
		for j = i:N
			I(i,j) = mcik({st{i},st{j}}, ksize);
		end
	end
else
	for i = 1:N
		for j = i:N
			I(i,j) = mcik({st{i},st{j}}, ksize, kern_str);
		end
	end
end
if (N == 2)
	I = I(1,2);
else
	I = I + I' - diag(diag(I));
end

