%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification of spike trains from RENEWAL point processes,
% using Kernel Fisher Linear Discriminant.
%
% MONTE CARLO TESTS for the nCI kernel.
%
% DATASET GENERATION:
% Spike trains were generated as homogeneous renewal point processes,
% with either a lognormal or gamma ISI distribution.
%
% Antonio Paiva
% Jun 29, 2009
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear; close all
rand ('state',20090629);
randn('state',20090629);

%% settings
%=====================================================================

MC = 100;
nTrainSpikeTrains = 50;
nTestSpikeTrains = 200;

ksize = 50E-3;			% width for smoothing function
Ks = [0.1 1 10];

% parameters for renewal point processes
distrib = 'gamma';
distrib_param = [0.5 3];
T = 1;					% length of each spike train (sec)
rate = 20;

%% MC runs
%=====================================================================

tic
Pe = ones(length(Ks),MC);
for k = 1:length(Ks)
for m = 1:MC
	i = (k-1)*MC + m;
	fprintf('\rKs=%.1f, MC %d/%d  (etf %.1f min)', Ks(k), m, MC, ...
			((MC*length(Ks)-i+1)*toc/((i-1)+1E-2)/60));

	% generate spike trains
	%=====================================================================
	
	% generate training data
	stSetTrain = cell(1,nTrainSpikeTrains);
	for i = 1:2
		for j = 1:nTrainSpikeTrains/2
			idx = (i-1)*(nTrainSpikeTrains/2) + j;
			while (1)
				stSetTrain{idx} = generateHomogeneousRenewalSpikeTrain(...
										rate, T, distrib, distrib_param(i));
				if (~isempty(stSetTrain{idx})), break; end
			end
		end
	end
	stSetTrain1 = stSetTrain(1:nTrainSpikeTrains/2);
	stSetTrain2 = stSetTrain(nTrainSpikeTrains/2+1:end);
	labelsTrain = [zeros(1,nTrainSpikeTrains/2), ones(1,nTrainSpikeTrains/2)];
	
	% generate test data
	stSetTest = cell(1,nTestSpikeTrains);
	for i = 1:2
		for j = 1:nTestSpikeTrains/2
			idx = (i-1)*(nTestSpikeTrains/2) + j;
			while (1)
				stSetTest{idx} = generateHomogeneousRenewalSpikeTrain(...
										rate, T, distrib, distrib_param(i));
				if (~isempty(stSetTest{idx})), break; end
			end
		end
	end
	stSetTest1 = stSetTest(1:nTestSpikeTrains/2);
	stSetTest2 = stSetTest(nTestSpikeTrains/2+1:end);
	labelsTest = [zeros(1,nTestSpikeTrains/2), ones(1,nTestSpikeTrains/2)];

	% compute KFD with nCI
	%=====================================================================
	
	nci_handler = @(st) ncik2(st, T, ksize, 1);
	
	% compute KFD parameters: projection vector and threshold
	fd = kfd(stSetTrain, labelsTrain, nci_handler);
	
	% classify the test data
	[z y Pe(k,m)] = kfd_classify(fd, stSetTest, labelsTest);

end
	save('mat_mc_nci.mat','Pe');
	fprintf('\n --> Ks = %.1f: Pe = %.3f +/- %.3f\n', Ks(k), ...
								mean(Pe(k,:)), std(Pe(k,:)));
end
