function kernelHandle = mcikernel(tau, kfunc)
% CI kernel handle generator
% tau = kernel size
% kfunc = kernel function to use {'laplacian','gaussian','rect'}
%
% $Id: cikernel.m 222 2007-05-22 16:18:16Z memming $
% Copyright 2007 Antonio and Memming, CNEL, all rights reserved.

% TODO: currently every evaluation of the kernel performs strcmp, which is very slow.

kernelHandle = @cik;

function v = cik(st1, st2)
    v = 0;

    if strcmp(kfunc,'gaussian')
	for k = 1:length(st1)
	    for kk = 1:length(st2)
		v = v + exp(-(st1(k) - st2(kk))^2 / (2*tau^2));
	    end
	end
	v = v / (sqrt(2 * pi) * tau);

    elseif strcmp(kfunc,'rect')
	for k = 1:length(st1)
	    for kk = 1:length(st2)
		v = v + (abs(st1(k) - st2(kk)) < tau);
	    end
	end
	v = v / (2 * tau);

    else % default: 'laplacian'
	for k = 1:length(st1)
	    for kk = 1:length(st2)
		v = v + exp(-abs(st1(k) - st2(kk))/tau);
	    end
	end
	v = v / (2 * tau);
    end

end % function cik
end % function cikernel

% vim: set ts=8 sts=4 sw=4: (modeline)
