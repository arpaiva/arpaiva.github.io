function fd = kfd(stCell, labels, kernel)
% Kernel Fisher Discriminant of spike trains onto two classes.
%
% Input:
%   stCell: (1xN) cell array of spike trains
%   labels: (1xN) array with the true class labels (0/1 or -1/1)
%   kernel: (function handle: st x st -> R) kernel/inner product function
%
% Output:
%   fd: a structure with the info:
%	 fd.stCell: stCell
%	 fd.labels: class labels
%	 fd.kernel: kernel function handle
%	 fd.N: number of spike trains
%	 fd.w: (Nx1) projection eigenvector that maximizes Fisher's criterion
%	 fd.b: optimum threshold for classification from training data
%	 fd.z: (1xN) classifier output classification labels on training data
%	 fd.pe: prob of error in training set
%
% See also: kfd_classify
%
% Copyright 2009 Antonio, SCI Institute, Univ. of Utah, all rights reserved.

N = length(stCell);
if (N < 2)
	error('At least two spike trains are needed');
end

lbl = sort(unique(labels), 'ascend');
if length(lbl) > 2;
    error('Labels provided for more than two classes');
else
	% transform labels to 0/1 format
	labels(labels == lbl(1)) = 0;
	labels(labels == lbl(2)) = 1;
end

% initialize the output structure
fd.stCell = stCell;
fd.labels = labels;
fd.kernel = kernel;
fd.N = N;

% computing Gram matrix
K = kernel(stCell);
%K = zeros(N, N);
%for i = 1:N
%    for j = 1:N
%		K(i, j) = kernel(stCell{i}, stCell{j});
%    end
%end

% compute matrix corresponding to the intra-cluster matrix
m0 = mean(K(:,labels==0),2);
m1 = mean(K(:,labels==1),2);
% S_b = (m0 - m1) * (m0 - m1)';

% compute matrix corresponding to the inter-cluster matrix
n0 = sum(labels == 0);
n1 = sum(labels == 1);
S_w = (1/n0).*K(:,labels==0)*(eye(n0) - ones(n0)./n0)*K(labels==0,:) ...
		+ (1/n1).*K(:,labels==1)*(eye(n1) - ones(n1)./n1)*K(labels==1,:);

% compute projection eigenvector
fd.w = inv(S_w + 1E-3.*eye(size(S_w))) * (m1 - m0);
% % regularize S_w
% [V E] = eig(S_w);
% E = real(diag(E));
% E(E < 10E-12*max(E)) = 10E-12*max(E);
% fd.w = (V * diag(1./E) * V') * (m1 - m0);	% (V * diag(1./E) * V') = inv(S_w)
fd.w = fd.w ./ sqrt(sum(fd.w.^2));	% make the proj vector unit norm

% project data
fd.y = K * fd.w;

% find optimum threshold
[aux i] = sort(fd.y, 'ascend');    % sort the projected data
labels = labels(i);
c0_sum = cumsum(labels == 0);
c1_sum = cumsum(labels == 1);
[pc0 i] = max(((c1_sum(end) - c1_sum) + c0_sum) / (n0+n1));
[pc1 j] = max((c1_sum + (c0_sum(end) - c0_sum)) / (n0+n1));
if (pc0 >= pc1)
    fd.b_mode = 1;
    fd.b = mean(aux([i i+1]));
    fd.Pe = 1 - pc0;
else
    fd.b_mode = -1;
    fd.b = mean(aux([i-1 i]));
    fd.Pe = 1 - pc1;
end

% vim: set ts=4: (modeline)
