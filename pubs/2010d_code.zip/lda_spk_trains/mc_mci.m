%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Classification of spike trains from RENEWAL point processes,
% using Kernel Fisher Linear Discriminant.
%
% MONTE CARLO TESTS for the mCI kernel.
%
% DATASET GENERATION:
% Spike trains were generated as homogeneous renewal point processes,
% with either a lognormal or gamma ISI distribution.
%
% Antonio Paiva
% Jun 29, 2009
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear; close all
rand ('state',20090629);
randn('state',20090629);

%% settings
%=====================================================================

MC = 500;
nTrainSpikeTrains = 50;
nTestSpikeTrains = 200;

% mCI
kfunc = 'laplacian';	% kernel to use in the mCI kernel estimator
ksize = 50E-3;			% width/bin size/kernel for smoothing function
						% and kernel size for mCI estimator

% parameters for renewal point processes
distrib = 'gamma';
distrib_param = [0.5 3];
T = 1;					% length of each spike train (sec)
rate = 20;

%% MC runs
%=====================================================================

tic
Pe = ones(1,MC);
for m = 1:MC
	fprintf('\rMC %d/%d  (etf %.1f sec)', m, MC, ...
			((MC-m+1)*toc/((m-1)+1E-2)));

	% generate spike trains
	%=====================================================================
	
	% generate training data
	stSetTrain = cell(1,nTrainSpikeTrains);
	for i = 1:2
		for j = 1:nTrainSpikeTrains/2
			idx = (i-1)*(nTrainSpikeTrains/2) + j;
			while (1)
				stSetTrain{idx} = generateHomogeneousRenewalSpikeTrain(...
										rate, T, distrib, distrib_param(i));
				if (~isempty(stSetTrain{idx})), break; end
			end
		end
	end
	stSetTrain1 = stSetTrain(1:nTrainSpikeTrains/2);
	stSetTrain2 = stSetTrain(nTrainSpikeTrains/2+1:end);
	labelsTrain = [zeros(1,nTrainSpikeTrains/2), ones(1,nTrainSpikeTrains/2)];
	
	% generate test data
	stSetTest = cell(1,nTestSpikeTrains);
	for i = 1:2
		for j = 1:nTestSpikeTrains/2
			idx = (i-1)*(nTestSpikeTrains/2) + j;
			while (1)
				stSetTest{idx} = generateHomogeneousRenewalSpikeTrain(...
										rate, T, distrib, distrib_param(i));
				if (~isempty(stSetTest{idx})), break; end
			end
		end
	end
	stSetTest1 = stSetTest(1:nTestSpikeTrains/2);
	stSetTest2 = stSetTest(nTestSpikeTrains/2+1:end);
	labelsTest = [zeros(1,nTestSpikeTrains/2), ones(1,nTestSpikeTrains/2)];

	% compute KFD with mCI kernel
	%=====================================================================
	
	mcik_handler = @(st) fh_mcik(st, ksize, kfunc);
	
	% compute KFLDA parameters: projection vector and threshold
	fd = kfd(stSetTrain, labelsTrain, mcik_handler);
	
	% classify the test data
	[z y Pe(m)] = kfd_classify(fd, stSetTest, labelsTest);
end

save('mat_mc_mci.mat','Pe');
fprintf('\n --> Pe = %.3f +/- %.3f\n', mean(Pe), std(Pe));
