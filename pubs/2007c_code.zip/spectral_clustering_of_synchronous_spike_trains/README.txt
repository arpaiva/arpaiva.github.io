Instructions of Matlab code for:
----------------------------------------------------------------
"Spectral Clustering of Synchronous Spike Trains",
Antonio R. C. Paiva, Sudhir Rao, Il Park, Jose C. Principe,
Proceedings of the International Joint Conference on Neural Networks (IJCNN),
(Orlando, FL), July 2007,
----------------------------------------------------------------

0. Copyright notice

    (c) 2007 Antonio Paiva and Il Park

    This code is provided as is, with no guarantees except that 
    bugs are almost surely present.  Published reports of research 
    using this code (or a modified version) should cite the 
    article above referenced that describes the algorithm.

    Comments and bug reports are welcome. Email to arpaiva@cnel.ufl.edu. 
    I would also appreciate hearing about how you used this code, 
    improvements that you have made to it, or translations into other
    languages.    

    You are free to modify, extend or distribute this code, as long 
    as this copyright notice is included whole and unchanged.  

1. Contents 

	The following files are included:

	cmds_sync.m
	cmds_sync_jitter.m
	generateHomogeneousPoissonSpikeTrain.m
	spktrain_vanRossumDist.m

	The first two files replicate the results published in the paper. The
	first without jitter, and the second with jitter added. To run simply
	type the file name. The script will generate a dataset as described in
	the paper and run the clustering algorithm on it.

	The section where clustering effectively takes place is marked by a
	"do spectral clustering" header comment. So, to try it on your dataset
   	simply copy this code and define the parameters: tau, sigma and Nc.

