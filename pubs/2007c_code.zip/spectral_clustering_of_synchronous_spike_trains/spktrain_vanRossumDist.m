function D = spktrain_vanRossumDist(x, tau)
%D = spktrain_vanRossumDist(X, TAU)
% Returns the van Rossum's distance between two spike trains.
% If more than two neurons are provided, it creates an NxN matrix
% (N=number of spike trains) with the distance between all pairs.
%
%    X: Data, organized as a cell array, with each cell containing an
%       array of spike times (in seconds).
%  TAU: Exponential decay parameter (in seconds).

% Copyright (c) Antonio Paiva
% Jan 2007

if (~iscell(x))
	error('X must be a cell array!');
end
N = length(x);
if (N < 2)
	error('Need at least two spike trains to operate');
end

% single spike train terms
single_st = zeros(N,1);
for i = 1:N
	single_st(i) = st_Laplacian_kernel(x{i}, x{i}, tau);
end

D = zeros(N);
aux = cell(2,1);
for i = 1:(N-1)
	for j = (i+1):N
		D(i,j) = st_Laplacian_kernel(x{i}, x{j}, tau);	% compute cross-term
		D(i,j) = (single_st(i) + single_st(j)) / 2 + D(i,j);
	end
end
if (N == 2)
	D = D(2,1);
else
	D = D + D';
end

%===========================================
function s = st_Laplacian_kernel(a,b,tau);
s = 0;
for m = 1:length(a)
for n = 1:length(b)
	s = s + exp(-abs(a(m) - b(n)) / tau);
end
end

