%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Spectral clustering of spike trains.
% ***Like cmds_sync.m but with jitter on the spike timmings.
%
% DATASET GENERATION:
% Generate 3 different spike trains that correspond to the 
% synchronous spikes of the 3 clusters.
% Generate samples from each cluster by adding additional spikes
% obtained from an independent spike train for a synchrony index
% of 0, 0.1 and 0.2, respectively.
% Enforce an absolute refractory period of 3ms.
%
% Antonio Paiva
% Jan 2007
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear
% close all
rand('seed',20070130);

% settings
Nc = 3;		% number of clusters
M = 100;	% number of test spike trains
MC = 10;		% Monte Carlo runs
T = 2;		% length of each spike train (sec)
fr = 20;
tau = [2 5 10]*1E-3;	% kernel size for IP and CIP
sync = [0.1 0.2];
jitter = [0 : 10]*1E-3;		% jitter standard deviation in seconds
sigma = 5;
verbose = 1;
vverbose = 0;

cluster_results.avg = zeros(length(jitter),length(sync),length(tau));
cluster_results.stddev = zeros(length(sync),length(sync),length(tau));
IT = length(sync) * length(tau) * length(jitter) * MC;
for k = 1:length(tau)
	for n = 1:length(sync)
		for l = 1:length(jitter)
			aux_results = zeros(MC,1);
			for m = 1:MC	% Monte Carlo runs
				if (verbose)
					aux = (k-1)*length(sync)*length(jitter)*MC + ...
						(n-1)*length(jitter)*MC + (l-1)*MC + m;
					fprintf(['\rtau: %.1f, synchrony: %.3f, jitter: %.1f ' ...
						'[%d/%d]'], tau(k)/1E-3, sync(n), ...
						jitter(l)/1e-3, aux, IT);
				end
        
				% generate spike trains
				%-----------------------------
				if (vverbose), fprintf('  + generate data...\n'); end
				
				% generate ensemble synchronous spikes
				main_sync = cell(3,1);
				if (sync(n) > 0)
					for i = 1:Nc
						main_sync{i} = generateHomogeneousPoissonSpikeTrain(sync(n)*fr, T);
					end
				end
				% generate random assignment of clusters
				cluster_labels = ceil(Nc * rand(1,M));
				% generate test spike trains
				data = cell(M,1);
				for i = 1:M
					% jitter synchronous spike times
					jittered_times = main_sync{cluster_labels(i)} + ...
						jitter(l) .* randn(size(main_sync{cluster_labels(i)}));

					% add non-synchronous spikes to spike train
					data{i} = sort([jittered_times, ...
						generateHomogeneousPoissonSpikeTrain((1-sync(n)) * fr, T)]);
					% enforce absolute refractory period
					% (but do not remove synchronous spikes)
					aux = find(diff(data{i}) < 3E-3) + 1;
					for j = 1:length(aux)
						tmp = find(data{i}(aux(j)) == jittered_times);
						if (length(tmp) > 0)
							tmp = jittered_times(tmp);
							if (aux(j) == length(data{i}))
								aux(j) = aux(j) - 1;
							elseif (data{i}(aux(j)+1)-tmp < tmp-data{i}(aux(j)-1)) 
								aux(j) = aux(j) + 1;
							else
								aux(j) = aux(j) - 1;
							end
						end
					end
					data{i}(aux) = [];
				end
				
				% do spectral clustering
				%---------------------------------
				if (vverbose), fprintf('  + spectral clustering...\n'); end
        
				% 1. affinity matrix
				A = spktrain_vanRossumDist(data, tau(k));
				A = exp(-A./(2*sigma^2));
				A = A .* (1 - eye(size(A)));
				% 2. normalization
				D = diag(sum(A,2));
				L = (D^-.5) * A * (D^-.5);
				% 3 & 4. eigendecomposition
				if (vverbose), fprintf('    + eigendecomposition...\n'); end
				[V d] = eig(L);
				[d idx] = sort(diag(d),1,'descend');
				X = V(:,idx(1:Nc));
				Y = X ./ repmat(sqrt(sum(X.^2,2)),1,Nc);
				% 5. cluster points of Y
				if (vverbose), fprintf('    + clustering points...\n'); end
				[idx C] = kmeans(Y, Nc, 'replicates',10, 'EmptyAction','singleton');
        
				% evaluate clustering
				%---------------------------------
            
				% reorder to cluster labels to match original values
				tmp = perms(1:Nc);
				best = 0;
				for i = 1:size(tmp,1)
					aux = sum(tmp(i,idx) == cluster_labels);
					if (aux > best)
						j = i;
						best = aux;
					end
				end
				idx = tmp(j,idx);
        
				aux_results(m) = best;
            
				%if (m == MC)
					% figure(1), clf, hold all
					% c = [0 0 1; 0 0.5 0; 1 0 0];
					% for i = 1:Nc
					% 	aux = find(idx == i);
					% 	tmp1 = aux(find(cluster_labels(aux) == i));	% correct
					% 	tmp2 = aux(find(cluster_labels(aux) ~= i)); % incorrect
					% 	plot(Y(tmp1,1), Y(tmp1,2), 's', ...
					% 			Y(tmp2,1), Y(tmp2,2), 'x', 'Color',c(i,:));
					% end
					% figure(3), clf, hold on
					% c = {'s','o','x','d'};
					% subplot(121), hold on
					% for i = 1:Nc
					% 	aux = find(idx == i);
					% 	scatter(Y(aux,1), Y(aux,2), c{i});
					% end
					% subplot(122), hold on
					% for i = 1:Nc
					% 	aux = find(cluster_labels == i);
					% 	scatter(Y(aux,1), Y(aux,2), c{i});
					% end
					% xlabel('y1'), ylabel('y2'), set(gca, 'Box','on')
					% fn = sprintf('fig_clusters_sync%0.3f_tau%02f', ...
					% 										sync(n), tau(k)/1E-3);
					% saveas(1,[fn '.eps'],'epsc2')
					% saveas(1,[fn '.png'],'png')
				%end
            
			end % Monte Carlo runs
			aux_results = aux_results ./ M;
			cluster_results.avg(l,n,k) = mean(aux_results);
			cluster_results.stddev(l,n,k) = std(aux_results);
		end % jitter
	end % synchrony levels
end % tau values
fprintf('\n');

fn = sprintf('mat_results_jitter_Nc%d_Np%03d_MC%03d_sigma%02d.mat', Nc, M, MC, sigma);
save(fn,'cluster_results','Nc','M','MC','T','sigma','fr','tau','sync','jitter')

% for sig = [1 5 10 20]
% fn = sprintf('mat_results_jitter_Nc%d_Np%03d_MC%03d_sigma%02d.mat', Nc, M, MC, sig);
% load(fn)
	figure(2), clf, hold all
	set(gca, 'Box','on','FontSize',14)
	c = {'s','d','o'};
	s = {':','-'};
	color = [0 0.5 0; 0 0 1];	% green / blue
	str = {};
	for j = 1:length(sync)
		for i = 1:length(tau)
		% 	errorbar(sync, cluster_results.avg(:,j,i), cluster_results.stddev(:,i,j), c{i});
			plot(jitter/1E-3, cluster_results.avg(:,j,i), [c{i} s{j}], ...
														'LineWidth', 2,...
														'Color', color(j,:));
			str{end+1} = [num2str(sync(j)),', ',num2str(tau(i)/1E-3),'ms'];
		end
	end
	legend(str, 'Location','SouthWest');
	xlabel('Jitter standard deviation (ms)'), ylabel('Prob. correct')
	ax = axis; axis([-0.1 max(jitter/1E-3)+0.1 ax(3) 1.02])
	fn = sprintf('fig_probCorrect_jitter_Nc%d_Np%03d_MC%03d_sigma%02d', Nc, M, MC, sigma);
	saveas(2,[fn '.eps'],'epsc2')
	saveas(2,[fn '.png'],'png')
% end
