function res = compute_saliency(file_name, max_pcs)

patch_size = 11;
if (nargin < 1) || isempty(file_name)
	error('Please specify the image to analyze.');
elseif (nargin < 2) || (max_pcs < 1)
	max_pcs = 5;
end
[x img_name] = fileparts(file_name);

%--------------------------------------------------------------------------
disp(' > Loading data...');
img = single(imread(file_name)) ./ 255;

half_patch = floor((patch_size - 1) / 2);
offset = SquareNeighborhood(half_patch);
fv = ConstructNeighborhoods(img, offset, 0);
fv = bsxfun(@minus, fv, mean(fv,2));

%--------------------------------------------------------------------------
disp(' > Computing projections...');
[x r v e] = PCAprojection(fv,8);

%--------------------------------------------------------------------------
figure(1), plot(e,'s-', 'LineWidth',1.5)
xlim([0.75 numel(e)+.25]);
set(gca,'FontSize',14);
xlabel('index','FontSize',16)
ylabel('eigenvalue','FontSize',16)
title('original image', 'FontSize',18)
% saveas(gcf, sprintf('%s_eigvals', img_name),'epsc2')
% saveas(gcf, sprintf('%s_eigvals', img_name),'png')

%--------------------------------------------------------------------------
[aux npcs] = max(-diff(e));
fprintf(' > eigenvalues suggest that using the %d-th residual image may be sufficient...\n', min(npcs))

%--------------------------------------------------------------------------
img = img(half_patch+1:end-half_patch, half_patch+1:end-half_patch);
res = cell(1, max_pcs);
for n = 1:max_pcs
	fprintf(' > %d-th residual image...\n', n);

	y = sqrt(sum((fv - v(:,1:n)*x(1:n,:)).^2, 1));
	res{n} = reshape(y, size(img));

	% show saliency (i.e., residual image) after removing the first n
	% principal components
	figure(10+n), clf
	imagesc(res{n})
	axis image off, colorbar
	title(sprintf('residual after removing %d PCs', n), 'FontSize',18)
end

