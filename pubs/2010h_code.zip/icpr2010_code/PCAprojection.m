function [proj res v e] = PCAprojection(x, ndims)
%[projections residual eigenvectors eigenvalues] = PCAprojection(x, ndims)
%  Compute the PCA projectionn of x (NxL; N=# of dimensions, L=# of samples)

% Copyright (c) Antonio Paiva, SCI institute, Univ. of Utah
% Last modified: Jan 29, 2009

x = x - mean(x,2) * ones(1,size(x,2));	% center data, i.e., remove mean
Q = (x * x') ./ size(x,2);
[v e] = eig(Q);
[e idx] = sort(real(diag(e)), 'descend');
e = e(1:ndims);
v = v(:,idx(1:ndims));
proj = v' * x;
res = zeros(1,min([length(e) (4*ndims)]));
for j = 1:length(res)
	res(j) = sum(e(j+1:end)) / sum(e);
end

