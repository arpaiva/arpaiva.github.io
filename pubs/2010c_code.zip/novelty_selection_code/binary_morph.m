function out = binary_morph(in, h, func, flag)
%out = binary_morph(in, h, func, [flag])
% Morphological operations on *binary* image 'in'. Known morphological
% operations are: 'dilate','erode','opening','closing'.
%
% Inputs:
%   in     binary input image
%   h      masking element; must be nxn, with n an odd number
%   func   name of the operation
%   flag   if the image should be padded with zeros (flag = 0)
%          or extended (flag = 1; this is the default)

if (nargin < 3)
	error('Not enough arguments');
elseif (nargin < 4)
	flag = 1;
end
if (size(h,1) ~= size(h,2)) || (mod(size(h,1),2) ~= 1)
	error('Masking element must be nxn, with n an odd number');
end

switch lower(func)
	case 'dilate'
		out = dilation(in,h,flag);
	case 'erode'
		out = erosion(in,h,flag);
	case 'opening'
		out = dilation(erosion(in,h,flag),h,flag);
	case 'closing'
		out = erosion(dilation(in,h,flag),h,flag);
	otherwise
		error('Unknown operation.');
end


%--------------------------------------------------------------------------
function y = dilation(x,h,flag)
[M N] = size(x);

Hd = size(h,1);			% side dimension of the structuring element
Hc = ceil(Hd/2);		% (Hc,Hc) = origin of the structuring element
Hsum = sum(sum(h));
hr = flipud(fliplr(h));

x = pad_img(x, Hc-1, flag);
y = zeros(M,N);
% for i = 1:M
% 	for j = 1:N
% 		h_aux = hr((i>=Hrc)+(i<Hrc)*(Hrc-i+1):(M-i>=Hr-Hrc)*Hr+(M-i<Hr-Hrc)*(Hrc+M-i),...
% 			(j>=Hcc)+(j<Hcc)*(Hcc-j+1):(N-j>=Hc-Hcc)*Hc+(N-j<Hc-Hcc)*(Hcc+N-j));
% 		img_aux = x(max([1,i-Hrc+1]):min([M,i+(Hr-Hrc)]),...
% 			max([1,j-Hcc+1]):min([N,j+(Hc-Hcc)]));
for i = 1:M
	for j = 1:N
		y(i,j) = (sum(sum((hr & x(i+[0:Hd-1], j+[0:Hd-1])))) > 0);
	end
end
clear x

%--------------------------------------------------------------------------
function y = erosion(x,h,flag)
[M N] = size(x);

Hd = size(h,1);		% side dimension of the structuring element
Hc = ceil(Hd/2);		% (Hc,Hc) = origin of the structuring element
Hsum = sum(h(:));

x = pad_img(x, Hc-1, flag);
y = zeros(M,N);
for i = 1:M
	for j = 1:N
		y(i,j) = (sum(sum(h & x(i+[0:Hd-1], j+[0:Hd-1]))) == Hsum);
	end
end
clear x

%--------------------------------------------------------------------------
function y = pad_img(x,k,flag)
[M N] = size(x);
y = zeros(M+2*k, N+2*k);

% put original image in center
y(k+[1:M],k+[1:N]) = x;

if flag
	% fill top/bottom rows of padded image
	y(1:k, k+[1:N]) = repmat(x(1,:), k,1);
	y(end-k+1:end, k+[1:N]) = repmat(x(M,:), k,1);

	% fill left/right columns of padded image
	y(k+[1:M], 1:k) = repmat(x(:,1), 1,k);
	y(k+[1:M],end-k+1:end) = repmat(x(:,N), 1,k);

	% fill in corners of padded image
	y(1:k,1:k) = x(1,1);
	y(1:k,end-k+1:end) = x(1,N);
	y(end-k+1:end,1:k) = x(M,1);
	y(end-k+1:end,end-k+1:end) = x(M,N);
end

