function ui_semisupervised_img_seg(img_name, use_all_data, neighborhood_size)
% Interactive image segmentation (hence, the term "semi-supervised").
%
% Usage: ui_semisupervised_img_seg(img_name, use_all_data, neighborhood_size)
%
% Inputs:
%   img_name - image filename
%   use_all_data - use all the data (true) or novelty selection (false; default)
%   neighborhood_size - size of the image patch (default: 5)
%
% Output:
%   The function creates three images on the current path, with name based
%   on the input image. Those images include the "mask" of the resulting
%   segmentation, the segmentation result overlaid on the original image
%   (as shown in the paper), and the user input labels on the original image.
%
% Basically, the user selects two portions of the image from which we collect
% patches. These sets serve as reference when classifying other pixels
% (by comparing to their corresponding patches). Before classification,
% we apply a data reduction step to speed up the matching process.
%
% To draw lines, start the line with a middle button click and finish the line
% with the right or left button to set the label.
%
% If you use this code in a publication, please cite the paper:
%   Antonio R. C. Paiva and Tolga Tasdizen,
%   "Fast semi-supervised image segmentation using novelty selection,"
%   in Proceedings of ICASSP, Dallas, TX, USA, March 2010
%
% Antonio Paiva, SCI Institute, University of Utah
% This code is provided free but WITHOUT ANY WARRANTY.

% settings
if (nargin < 1) || isempty(img_name)
	img_name = 'images/house96x96.png';
end
if (nargin < 2) || isempty(use_all_data)
	use_all_data = false;	% i.e., use novelty selection :)
end
if (nargin < 3) || isempty(neighborhood_size)
	neighborhood_size = 5;
end

ksize_all = 0.25;	% kernel size if all the data is used
ksize = 1.0;		% kernel size with novelty selection
alpha = 0.1;
delta = 0.5;

%------------------------------------------------
% precompute some terms

% read and prepare input image
img = imread(img_name);
if isa(img, 'uint8')	% 8-bit image
	img = double(img) ./ 255;
elseif isa(img, 'uint16')	% 16-bit image
	img = double(img)./ (2^16-1);
else
	error('Don''t know how to handle the image...');
end
[inr inc inp] = size(img);

% extract patches
fprintf('Extracting patches... '); tic
fv = extract_patches(img, neighborhood_size);
fprintf('done (%.1fs)\n', toc);

N = size(fv,2);		% number of pixels/patches
if (inp == 1), img = repmat(img,[1 1 3]); end

% novelty selection or pre-compute W
if (~use_all_data)
	fprintf('Novelty selection... '); tic
	[z ns_idx idx] = novelty_selection_seq(fv, delta);
	fprintf('done [%d -> %d] (%.1fs)]  \n', N, size(z,2), toc);
else
	tic
	W = sparse(N,N);
	for i = 1:100:N
		fprintf('\rPre-computing S: %d/%d', (i-1)/100+1, ceil(N/100));
		w = sqrL2dist(fv,fv(:,[i : min([i+99 N])]));
		w = exp(-w ./ (2*ksize_all^2));
		w(w < 1E-3) = 0;
		W(:,[i : min([i+99 N])]) = sparse(w);
	end
	W = W - spdiags(diag(W), 0, N, N);	% remove diagonal
	D = sparse(1:N, 1:N, 1./sqrt(sum(W,2)));
	S = sparse(D*W*D);
	fprintf(' ... done (%.1fs)\n', toc);
	clear W D
end

% mask for closing
xx = repmat([-neighborhood_size:neighborhood_size] , [2*neighborhood_size+1 1]);
yy = repmat([-neighborhood_size:neighborhood_size]', [1 2*neighborhood_size+1]);
h = (xx.^2 + yy.^2 <= neighborhood_size^2);

%------------------------------------------------
% start UI

% initialize UI variables...
marker_size = 5;
marker_str = sprintf('[ms: %d]', marker_size);
mask = zeros([inr inc]);
%
flag_quit_check = false;
flag_mask_change = false;	% indicates if changes occur in the user labeling
flag_update_tsp1 = true;	% update the title of subplot 1
%
seg = [];			% color image with the segmentation

% interface commands
fprintf(['Interface commands:\n' ...
	'  ''R''/''r''  increase/decrease the radius of the user marker\n' ...
	'    ''g''    compute segmentation\n' ...
	'    ''s''    save result and mask images\n' ...
	'    ''q''    quit!\n\n']);

% open figure interface
figure(1), clf, subplot(121), imagesc(img), axis image
title([marker_str '\bf Waiting for user command...']);
subplot(122), title(sprintf('[ns: %d]', neighborhood_size));

% start user interaction cycle...
while (1)
	[x y b] = ginput(1);
	switch (b)
	case 1		% left click
		if ((x > 0) && (y > 0) && (round(x) <= inc) && (round(y) <= inr))
			xx = repmat([1:inc] , [inr 1]);
			yy = repmat([1:inr]', [1 inc]);
			aux = (xx - x).^2 + (yy - y).^2;
			mask(aux <= marker_size^2) = 1;
			flag_mask_change = true;
		end
	case 3		% right click
		if ((x > 0) && (y > 0) && (round(x) <= inc) && (round(y) <= inr))
			xx = repmat([1:inc] , [inr 1]);
			yy = repmat([1:inr]', [1 inc]);
			aux = (xx - x).^2 + (yy - y).^2;
			mask(aux <= marker_size^2) = -1;
			flag_mask_change = true;
		end
	case 2		% middle click: start line
		if ((x > 0) && (y > 0) && (round(x) <= inc) && (round(y) <= inr))
			aux = zeros([inr inc]);
			x0 = x;
			y0 = y;
			figure(1), subplot(121)
			title([marker_str '{\bf Start line:} Click to mark end...']);
			[x y b] = ginput(1);
			if ((b == 1) || (b == 3)) && ((x > 0) && (y > 0) ...
									  && (round(x) <= inc) && (round(y) <= inr))
				% draw line
				if (abs(y-y0) < abs(x-x0))
					for i = round(min([x0 x])) : round(max([x0 x]))
						aux(round((i-x0)*(y-y0)/(x-x0) + y0), i) = 1;
					end
				else
					for i = round(min([y0 y])) : round(max([y0 y]))
						aux(i, round((i-y0)*(x-x0)/(y-y0) + x0)) = 1;
					end
				end
				% dilate line to proper thickness
				xx = repmat([-marker_size:marker_size] , [2*marker_size+1 1]);
				yy = repmat([-marker_size:marker_size]', [1 2*marker_size+1]);
				mh = (xx.^2 + yy.^2 <= marker_size^2);
				aux = binary_morph(aux, mh, 'dilate');
				% apply changes to mask
				if (b == 1)
					mask(aux(:) == 1) = 1;
				else % b == 3
					mask(aux(:) == 1) = -1;
				end
				flag_mask_change = true;
			end
		end
	case  82	% pressed 'R': increase marker size
		if (marker_size < 25)
			marker_size = marker_size + 2;
			marker_str = sprintf('[ms: %d]', marker_size);
		end
	case 114	% pressed 'r': decrease marker size
		if (marker_size >= 3)
			marker_size = marker_size - 2;
			marker_str = sprintf('[ms: %d]', marker_size);
		end
	case 103	% pressed 'g': do the analysis

		if isempty(seg)		% if mask changed since last time the segmentation was computed
			[aux str] = fileparts(img_name);
			imwrite((mask+1)./2, [str '_mask.png'], 'png');

			% image segmentation: use consistency method
			fprintf('Image segmentation... '); tic
			if (use_all_data)
				lbl = reshape(((speye(N) - alpha.*S) \ mask(:)) > 0, [inr inc]);
			else
				% make sure all labeled points are in the computation set
				i = setdiff(find(mask(:) ~= 0), ns_idx);
				zz = [z, fv(:,i)];
				i = [ns_idx, i];
				% compute affinity matrix
				np = length(i);
				W = sparse(np,np);
				for j = 1:100:np
					w = sqrL2dist(zz,zz(:,[j : min([j+99 np])]));
					w = exp(-w ./ (2*ksize_all^2));
					w(w < 1E-3) = 0;
					W(:,[j : min([j+99 np])]) = sparse(w);
				end
				W = W - spdiags(diag(W), 0, np, np);	% remove diagonal
				D = sparse(1:np, 1:np, 1./sqrt(sum(W,2)));
				S = sparse(D*W*D);
				fprintf('[S: %.1fs] ', toc);
				% compute segmentation of the selected points
				tmp = (((speye(np) - alpha.*S) \ mask(i)') > 0);
				% apply computed labels to all other pixels
				lbl = zeros([inr inc]);
				lbl(i) = tmp;
				for j = 1:size(z,2)
					lbl(idx == j) = tmp(j);
				end
			end
			fprintf('done (%.1fs) \n', toc);

			% % force segmentation for user labeled pixels
			% lbl(mask > 0) = 1;
			% lbl(mask < 0) = 0;

			% apply closing
			lbl = binary_morph(lbl, h, 'closing');

			seg = mk_lbl_img(img, 2.*lbl-1);
			figure(1), subplot(122), imagesc(seg), axis image
			title(sprintf('[ns: %d]', neighborhood_size));
		end

	case 115	% pressed 's': save result image and mask
		[aux str] = fileparts(img_name);
		str = [str num2str(use_all_data)];
		if ~isempty(seg)
			imwrite(seg, ['fig_seg_' str '_result.png'], 'png');
			imwrite(lbl, ['fig_seg_' str '_mask.png'  ], 'png');
			aux = mk_mask_img(img, mask);
			imwrite(aux, ['fig_seg_' str '_ui.png'    ], 'png');
		end
	case 113	% pressed 'q': quit
		if (flag_quit_check)
			figure(1), subplot(121), title('\bf Bye...'); drawnow;
			return;
		else
			figure(1), subplot(121), title([marker_str ...
					'\bf Press ''q'' again to quit..']);
			flag_quit_check = true;
			flag_update_tsp1 = false;
		end
	otherwise
		figure(1), subplot(121)
		title([marker_str ' Unknown command?! (use ''q'' to quit)' ...
			'\newline\bf Waiting for user command...']);
		flag_update_tsp1 = false;
	end

	% reset quit_check flag
	if (b ~= 113)	% i.e., not 'q' pressed
		flag_quit_check = false;
	end

	% process image
	if (flag_mask_change)
		flag_mask_change = false;
		seg = [];	% segmentation result is inconsistent with labeling
		% update user labeling image
		aux = mk_mask_img(img, mask);
		figure(1), subplot(121), imagesc(aux), axis image
		title([marker_str '{\bf Computing...}']); drawnow;
	end

	% update the title of subplot 1 (with intructions to the user)
	if (flag_update_tsp1)
		figure(1), subplot(121)
		title([marker_str '\bf Waiting for user command...']);
	end
	flag_update_tsp1 = true;
end


%-------------------------------------------------------------------------------
function fv = extract_patches(img, neighborhood_size)
[inr inc inp] = size(img);
radius = floor((neighborhood_size-1)/2);
offset = SquareNeighborhood(radius);
if (size(img,3) == 1)
	fv = ConstructNeighborhoods(img, offset, 1);
elseif (size(img,3) == 3)
	fv = zeros((neighborhood_size^2)*inp, inr*inc);
	fv([1:neighborhood_size^2],:) = ...
								ConstructNeighborhoods(img(:,:,1), offset, 1);
	fv([1:neighborhood_size^2] + neighborhood_size^2,:) = ...
								ConstructNeighborhoods(img(:,:,2), offset, 1);
	fv([1:neighborhood_size^2] + 2*(neighborhood_size^2),:) = ...
								ConstructNeighborhoods(img(:,:,3), offset, 1);
else
	error('Image has a strange number of planes!');
end

%-------------------------------------------------------------------------------
function I = mk_mask_img(I0, mask);
[inr inc inp] = size(I0);
if (inp ~= 3), error('Image should have three "color" planes!'); end
%aux = reshape(reshape(I0,[inr*inc 3]) * [0.3; 0.59; 0.11], [inr inc]);
%I = repmat(aux,[1 1 3]);
I = I0;
% R
tmp = I(:,:,1);
tmp(mask ~= 0) = 0;
I(:,:,1) = tmp;
% G
tmp = I(:,:,2);
tmp(mask > 0) = 0.6;
tmp(mask < 0) = 0.35;
I(:,:,2) = tmp;
% B
tmp = I(:,:,3);
tmp(mask > 0) = 0;
tmp(mask < 0) = 1;
I(:,:,3) = tmp;

%-------------------------------------------------------------------------------
function I = mk_lbl_img(I0, mask);
[inr inc inp] = size(I0);
if (inp ~= 3), error('Image should have three "color" planes!'); end
aux = reshape(reshape(I0, [inr*inc 3]) * [0.3; 0.59; 0.11], [inr inc]);
I = repmat(aux, [1 1 3]);
% find segment edges
b = zeros([inr inc]+2);
b(2:end-1,2:end-1) = single(mask > 0);
b(1,:) = b(2,:); b(end,:) = b(end-1,:); b(:,1) = b(:,2); b(:,end) = b(:,end-1);
b = filter2([0 1 0; 1 0 1; 0 1 0]./4, b, 'valid');
ib = find((b > 0.1) & (b < 0.9));
% R
tmp = aux;
tmp(mask > 0) = 0;
tmp(mask < 0) = 0;
I(:,:,1) = tmp;
% G
tmp = aux;
tmp(mask > 0) = 0.5.*aux(mask > 0) + 0.5;
tmp(mask < 0) = 0.5.*aux(mask < 0) + 0.3;
I(:,:,2) = tmp;
% B
tmp = aux;
tmp(mask > 0) = 0;
tmp(mask < 0) = 1;
I(:,:,3) = tmp;

