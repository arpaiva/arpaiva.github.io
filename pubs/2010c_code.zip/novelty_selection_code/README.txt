==============================================================================
Fast Semi-Supervised Image Segmentation using Novelty Selection

   Author: Antonio R. C. Paiva (arpaiva@sci.utah.edu)
     Date: March 23, 2010
  Website: http://www.sci.utah.edu/~arpaiva/
==============================================================================

0. Copyright notice __________________________________________________________

    Copyright (c) 2009-2010 Antonio R. C. Paiva

    This code is provided as is, with no guarantees whatsoever.
    Comments, questions, and bug reports are welcome. Email to
	arpaiva@sci.utah.edu. I would also appreciate hearing about how you
	used this code, improvements that you have made to it, or
	translations into other languages.    
    
    Published reports of research using this code (or a modified version) 
    should cite the article:

        Antonio R. C. Paiva and Tolga Tasdizen,
        "Fast semi-supervised image segmentation using novelty selection,"
        in Proceedings of ICASSP, Dallas, TX, USA, March 2010

    You are free to modify, extend or distribute this code, as long 
    as this copyright notice is included whole and unchanged.  


1. Getting started __________________________________________________________

The demo case is obtained by running 'ui_semisupervised_img_seg' without
arguments. This will open the 96x96 pixel version of the 'house' image,
allowing you to label portions of the image, and compute the
(semi-supervised) segmentation for the image. By default, the function uses
novelty selection and 5x5 image patches. Remember to look at the Matlab
window for an explanation of the interface commands. To draw label lines,
start the line with a middle click and finish the line with either the
right or left mouse click to set the label.

CAUTION: If you use all the data (i.e., without novelty selection), remember
		 to start with the smallest image available (the default) and see how 
		 much your system can handle... I will not be responsible if your 
		 computer crashes. See Section 3 for details.


2. General description ______________________________________________________

The two main Matlab functions to use the code are:

  ui_semisupervised_img_seg.m
  no_ui.m

The first provides an interface to label portions of the image and compute
the segmentation. The second computes the segmentation for an input image,
assuming that a label image is available with '_mask' appended to the image
name (this image can be obtained using ui_semisupervised_img_seg). Basically,
'no_ui' is 'ui_semisupervised_img_seg' without the user interface. It's main
purpose was to compare computation speed and accuracy of the results for the
same labeling.

Both functions take up to 3 arguments: the input image, a boolean flag
(or 0/1) indicating if all the data should be used (false means that
novelty selection is used), and the patch size. All these arguments are
optional. If omitted or empty, they are set to the default values.
Other parameter values, such as kernel sizes and delta, are set directly
inside the functions. They are set with the same values used in the paper
and known to work with all the examples given, showing that their role is
non-critical.

The function that implements the novelty selection algorithm is
'novelty_selection_seq.m'. Additionally, the Matlab code for the "two moons"
 example is also made available in the function '2moons_example.m'.


3. Provided results _________________________________________________________

For reference, the images used in the paper, and others, are stored in the
'images/' folder and with multiple resolutions. The label image used in the 
paper is also stored with the name suffix '_mask'. (For multiple resolutions,
the mask is simply a rescaling.) For comparison, detailed results are stored
in the 'results/' folder. Figures with '_ns_' in the name have been computed 
using novelty selection, and figures with '_all_' have been computed using
the naive approach. Computation times on a high-performance computing system
are stored in 'times_ns.txt' and 'times_all.txt'.

USING NOVELTY SELECTION, the segmentation for all the images provided has been 
tested on a laptop with 2GB of memory, running Linux and Matlab 2007a.
(For the larger images, some swapping was necessary.)

As mentioned in Section 1, please be careful if you decide to try computing
the segmentation using all the data. On a 8GB desktop, I was able to compute 
the segmentation but for only the smaller images. Most of the results
required the use of high-performance computing system because some of the
images would easily need more than 16GB of memory. Still, I'm not able to
provide results using all the data for all the images...

