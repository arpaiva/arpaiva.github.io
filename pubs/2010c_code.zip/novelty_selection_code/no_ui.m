function no_ui(img_name, use_all_data, neighborhood_size)
% Non-interactive version of the 'ui_semisupervised_img_seg' function.
%
% Usage: no_ui(img_name, use_all_data, neighborhood_size)
%
% Inputs:
%   img_name - image filename
%   use_all_data - use all the data (true) or novelty selection (false; default)
%   neighborhood_size - size of the image patch (default: 5)
%
% Output:
%   The function creates three images on the current path, with name based
%   on the input image. Those images include the "mask" of the resulting
%   segmentation, the segmentation result overlaid on the original image
%   (as shown in the paper), and the user input labels on the original image.
%
% If no arguments are provided, it computes the segmentation on the 'house'
% image (at 96x96 resolution) using novelty selection.
%
% If you use this code in a publication, please cite the paper:
%   Antonio R. C. Paiva and Tolga Tasdizen,
%   "Fast semi-supervised image segmentation using novelty selection,"
%   in Proceedings of ICASSP, Dallas, TX, USA, March 2010
%
% Antonio Paiva, SCI Institute, University of Utah
% This code is provided free but WITHOUT ANY WARRANTY.

if (nargin < 1) || isempty(img_name)
	img_name = 'images/house96x96.png';
end
if (nargin < 2) || isempty(use_all_data)
	use_all_data = false;
end
if (nargin < 3) || isempty(neighborhood_size)
	neighborhood_size = 5;
end

ksize_all = 0.25;	% kernel size if all the data is used
ksize = 1.0;		% kernel size with novelty selection
alpha = 0.1;
delta = 0.5;

%------------------------------------------------
% precompute some terms

% read and prepare input image
img = imread(img_name);
if isa(img, 'uint8')	% 8-bit image
	img = double(img) ./ 255;
elseif isa(img, 'uint16')	% 16-bit image
	img = double(img)./ (2^16-1);
else
	error('Don''t know how to handle the image...');
end
[inr inc inp] = size(img);

% extract patches
fprintf('Extracting patches... '); tic
fv = extract_patches(img, neighborhood_size);
fprintf('done (%.1fs)\n', toc);

N = size(fv,2);		% number of pixels/patches
if (inp == 1), img = repmat(img,[1 1 3]); end

% novelty selection or pre-compute W/S
if (~use_all_data)
	fprintf('Novelty selection... '); tic
	[z ns_idx idx] = novelty_selection_seq(fv, delta);
	fprintf('done [%d -> %d] (%.1fs)]  \n', N, size(z,2), toc);
else
	tic
	W = sparse(N,N);
	for i = 1:100:N
		fprintf('\rComputing the label propagation matrix (%d/%d)...', ...
													(i-1)/100+1, ceil(N/100));
		w = sqrL2dist(fv,fv(:,[i : min([i+99 N])]));
		w = exp(-w ./ (2*ksize_all^2));
		w(w < 1E-3) = 0;
		W(:,[i : min([i+99 N])]) = sparse(w);
	end
	W = W - spdiags(diag(W), 0, N, N);	% remove diagonal
	D = sparse(1:N, 1:N, 1./sqrt(sum(W,2)));
	S = sparse(D*W*D);
	fprintf(' done (%.1fs)\n', toc);
	clear W D
end

% mask for closing
xx = repmat([-neighborhood_size:neighborhood_size] , [2*neighborhood_size+1 1]);
yy = repmat([-neighborhood_size:neighborhood_size]', [1 2*neighborhood_size+1]);
h = (xx.^2 + yy.^2 <= neighborhood_size^2);

%------------------------------------------------
% compute segmentation

% load mask
[aux str] = fileparts(img_name);
str = [aux '/' str];
mask = (double(imread([str '_mask.png']))./255 - 0.5).*2;
mask(abs(mask) < 0.25) = 0;

% image segmentation: use consistency method
fprintf('Image segmentation... '); tic
if (use_all_data)
	lbl = reshape(((speye(N) - alpha.*S) \ mask(:)) > 0, [inr inc]);
else
	% make sure all labeled points are in the computation set
	i = setdiff(find(mask(:) ~= 0), ns_idx);
	zz = [z, fv(:,i)];
	i = [ns_idx, i];
	% compute affinity matrix
	np = length(i);
	W = sparse(np,np);
	for j = 1:100:np
		w = sqrL2dist(zz,zz(:,[j : min([j+99 np])]));
		w = exp(-w ./ (2*ksize_all^2));
		w(w < 1E-3) = 0;
		W(:,[j : min([j+99 np])]) = sparse(w);
	end
	W = W - spdiags(diag(W), 0, np, np);	% remove diagonal
	D = sparse(1:np, 1:np, 1./sqrt(sum(W,2)));
	S = sparse(D*W*D);
	fprintf('[S: %.1fs] ', toc);
	% compute segmentation of the selected points
	tmp = (((speye(np) - alpha.*S) \ mask(i)') > 0);
	% apply computed labels to all other pixels
	lbl = zeros([inr inc]);
	lbl(i) = tmp;
	for j = 1:size(z,2)
		lbl(idx == j) = tmp(j);
	end
end
fprintf('done (%.1fs) \n', toc);

% apply closing
lbl = binary_morph(lbl, h, 'closing');

% generate segmented image
seg = mk_lbl_img(img, 2.*lbl-1);

% save result image and mask
[aux str] = fileparts(img_name);
if (use_all_data)
	str = [str '_all'];
else
	str = [str '_ns'];
end
imwrite(seg, ['fig_seg_' str '_result.png'], 'png');
imwrite(lbl, ['fig_seg_' str '_mask.png'  ], 'png');
aux = mk_mask_img(img, mask);
imwrite(aux, ['fig_seg_' str '_ui.png'    ], 'png');

return


%-------------------------------------------------------------------------------
function fv = extract_patches(img, neighborhood_size)
[inr inc inp] = size(img);
radius = floor((neighborhood_size-1)/2);
offset = SquareNeighborhood(radius);
if (size(img,3) == 1)
	fv = ConstructNeighborhoods(img, offset, 1);
elseif (size(img,3) == 3)
	fv = zeros((neighborhood_size^2)*inp, inr*inc);
	fv([1:neighborhood_size^2],:) = ...
								ConstructNeighborhoods(img(:,:,1), offset, 1);
	fv([1:neighborhood_size^2] + neighborhood_size^2,:) = ...
								ConstructNeighborhoods(img(:,:,2), offset, 1);
	fv([1:neighborhood_size^2] + 2*(neighborhood_size^2),:) = ...
								ConstructNeighborhoods(img(:,:,3), offset, 1);
else
	error('Image has a strange number of planes!');
end

%-------------------------------------------------------------------------------
function I = mk_mask_img(I0, mask);
[inr inc inp] = size(I0);
if (inp ~= 3), error('Image should have three "color" planes!'); end
%aux = reshape(reshape(I0,[inr*inc 3]) * [0.3; 0.59; 0.11], [inr inc]);
%I = repmat(aux,[1 1 3]);
I = I0;
% R
tmp = I(:,:,1);
tmp(mask ~= 0) = 0;
I(:,:,1) = tmp;
% G
tmp = I(:,:,2);
tmp(mask > 0) = 0.6;
tmp(mask < 0) = 0.35;
I(:,:,2) = tmp;
% B
tmp = I(:,:,3);
tmp(mask > 0) = 0;
tmp(mask < 0) = 1;
I(:,:,3) = tmp;

%-------------------------------------------------------------------------------
function I = mk_lbl_img(I0, mask);
[inr inc inp] = size(I0);
if (inp ~= 3), error('Image should have three "color" planes!'); end
aux = reshape(reshape(I0, [inr*inc 3]) * [0.3; 0.59; 0.11], [inr inc]);
I = repmat(aux, [1 1 3]);
% find segment edges
b = zeros([inr inc]+2);
b(2:end-1,2:end-1) = single(mask > 0);
b(1,:) = b(2,:); b(end,:) = b(end-1,:); b(:,1) = b(:,2); b(:,end) = b(:,end-1);
b = filter2([0 1 0; 1 0 1; 0 1 0]./4, b, 'valid');
ib = find((b > 0.1) & (b < 0.9));
% R
tmp = aux;
tmp(mask > 0) = 0;
tmp(mask < 0) = 0;
tmp(ib) = 1;
I(:,:,1) = tmp;
% G
tmp = aux;
tmp(mask > 0) = 0.5.*aux(mask > 0) + 0.5;
tmp(mask < -0) = 0.5.*aux(mask < 0) + 0.3;
tmp(ib) = 1;
I(:,:,2) = tmp;
% B
tmp = aux;
tmp(mask > 0) = 0;
tmp(mask < 0) = 1;
tmp(ib) = 0.25;
I(:,:,3) = tmp;

