%============================================================================= 
% Make example for ICASSP paper.
%
% Image 1: data with labelings
% Image 2: result with semi-supervised learning on all the data
% Image 3: effect of novelty selection
% Image 4: result with semi-supervised learning on the representative
%          set, and labels assigned to all data by nearest neighbors
%
% We utilize the semi-supervised learning method proposed by
%   Zhou et al., "Learning with Local and Global Consistency", NIPS'2003
%
% If you use this code in a publication, please cite the paper:
%   Antonio R. C. Paiva and Tolga Tasdizen,
%   "Fast semi-supervised image segmentation using novelty selection,"
%   in Proceedings of ICASSP, Dallas, TX, USA, March 2010
%
% Antonio Paiva, SCI Institute, University of Utah
% This code is provided free but WITHOUT ANY WARRANTY.
%=============================================================================

clear; close all
rand ('state', 20090831);
randn('state', 20090831);

% data parameters
N = 500;	% number of points
noise_std = 0.1;
save_figs = false;

% novelty selection parameter
delta = 0.2;

% semi-supervised learning parameters
ksize1 = 0.1;
ksize2 = 0.25;
a = 0.99;

%---------------------------------------------------------------------
%% make dataset (two-moons dataset)

phase = 2*pi*rand(1,N);
aux = [cos(phase); sin(phase)] + noise_std.*randn(2,N);
i = (aux(2,:) >= 0);
n = sum(i);
x = zeros([2 N]);
x(1,1:n) = aux(1,i) - 0.5;
x(2,1:n) = aux(2,i) - 0.1;
x(1,(n+1):end) = aux(1,~i) + 0.5;
x(2,(n+1):end) = aux(2,~i) + 0.1;

% label two points
mask = zeros(1,N);
[aux i] = min(x(1,:));
[aux j] = max(x(1,:));
mask(i(1)) = -1;
mask(j(1)) = +1;

clear aux

%---------------------------------------------------------------------
%% Image 1: image with labeling

figure(1), clf
plot(x(1,:), x(2,:), '.', 'Markersize',12, 'Color',0.5*[1 1 1]); hold on
plot(x(1,mask==-1), x(2,mask==-1), 'bo', 'MarkerFace','b', 'MarkerSize',15);
plot(x(1,mask==+1), x(2,mask==+1), 'rs', 'MarkerFace','r', 'MarkerSize',15);
if (save_figs)
	saveas(1, 'fig_toy_example_orig', 'epsc2');
	saveas(1, 'fig_toy_example_orig', 'png');
end

%---------------------------------------------------------------------
%% Image 2: result with semi-supervised learning on all the data

tic
% compute Gram matrix and Laplacian
aa = repmat(sum(x.^2,1), [N 1]);
d2 = aa + aa' - 2.*(x' * x);	% *squared* Euclidean distance between points
W = exp(-d2 ./ (2*ksize1^2));
W = W - diag(diag(W));	% remove diagonal
D = diag(1./sqrt(sum(W,2)));
S = D*W*D;
clear W D

% label propagation
f = (eye(N) - a.*S) \ mask';
fprintf('Label propagation on the whole dataset took %f seconds.\n', toc);

figure(2), clf
plot(x(1,f<0), x(2,f<0), 'bo', 'LineWidth',1.5, 'MarkerSize',9); hold on
plot(x(1,f>0), x(2,f>0), 'rs', 'LineWidth',1.5, 'MarkerSize',9);
if (save_figs)
	saveas(2, 'fig_toy_example_ssl', 'epsc2');
	saveas(2, 'fig_toy_example_ssl', 'png');
end

%---------------------------------------------------------------------
%% Image 3: effect of novelty selection

figure(3), clf
plot(x(1,:), x(2,:), '.', 'Markersize',12, 'Color',0.5*[1 1 1]); hold on
tic
[z Iy Ix] = novelty_selection_seq(x, delta);
t0 = toc;
fprintf('Novelty selection took %f seconds.\n', t0);
plot(z(1,:), z(2,:), 'o', 'Color',[0 0.5 0], 'LineWidth',2, ...
	'MarkerSize',9, 'MarkerFace','g');
fprintf(' -> Reduced %d to %d points.\n', N, size(z,2));
if (save_figs)
	saveas(3, 'fig_toy_example_ns', 'epsc2');
	saveas(3, 'fig_toy_example_ns', 'png');
end

%---------------------------------------------------------------------
%% Image 4: results on the representative set, and labels assigned to all data

tic
% ensure the labeled points will be used in the analysis
i = setdiff(find(mask ~= 0), Iy);
zz = [z, x(:,i)];
i = [Iy, i];
xx = x(:,i);
n = size(zz,2);

% compute Gram matrix and Laplacian
aa = repmat(sum(xx.^2,1), [n 1]);
d2 = aa + aa' - 2.*(xx' * xx);	% *squared* Euclidean distance between points
W = exp(-d2 ./ (2*ksize2^2));
W = W - diag(diag(W));	% remove diagonal
D = diag(1./sqrt(sum(W,2)));
S = D*W*D;
clear W D

% label propagation
f = (eye(n) - a.*S) \ mask(i)';
t1 = toc;
fprintf('Label propagation in representative set took %f seconds.\n', t1);

tic
% assign labels to remaining data points
lbl = zeros(N,1);
lbl(i) = f;
for i = 1:size(z,2)
	lbl(Ix == i) = f(i);
end
t2 = toc;
fprintf('Assigning label to remaining points took %f seconds.\n', t2);
fprintf(' => Total time for NS + SSL is %f seconds.\n', t0 + t1 + t2);

% show result
figure(4), clf
plot(x(1,lbl<0), x(2,lbl<0), 'bo', 'MarkerSize',9, 'LineWidth',1.5); hold on
plot(x(1,lbl>0), x(2,lbl>0), 'rs', 'MarkerSize',9, 'LineWidth',1.5);
f = f(1:size(z,2));
plot(z(1,f<0),z(2,f<0), 'bo', 'MarkerSize',9,'MarkerFace','g','LineWidth',2);
plot(z(1,f>0),z(2,f>0), 'rs', 'MarkerSize',9,'MarkerFace','g','LineWidth',2);
if (save_figs)
	saveas(4, 'fig_toy_example_ns_ssl', 'epsc2');
	saveas(4, 'fig_toy_example_ns_ssl', 'png');
end

