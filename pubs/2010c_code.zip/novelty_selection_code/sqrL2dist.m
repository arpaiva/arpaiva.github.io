function d = sqrL2dist(a, b)
% sqrL2dist computes the *squared* Euclidean distance matrix
%
% D = sqrL2dist(A,B)
%
% *** Inputs ***
%    A,B : input matrices with column vectors (or the same dimensionality)
% 
% *** Output ***
%      D : squared Euclidean distances between vectors in A and B

% Antonio Paiva, SCI Institute, University of Utah
% last modified: Sep 01, 2009

if (nargin < 2)
	error('Not enough input arguments.');
elseif size(a,1) ~= size(b,1)
	error('A and B have different dimensionality.');
end

aa = repmat(sum(a.^2,1)', [1 size(b,2)]);
bb = repmat(sum(b.^2,1) , [size(a,2) 1]);
d = aa + bb - 2*(a' * b); 

