function [z ns_idx idx] = novelty_selection_seq(x, delta, z0)

% NOVELTY_SELECTION_SEQ selects a set of representative data points
%                       which retain the overall structure of the data.
%
% Usage: [z ns_idx idx] = novelty_selection_seq(x, delta, z0)
%
% *** Inputs ***
%         x: input data (column) vectors
%     delta: controls the coarseness of data reduction; that is, how
%            close should data points be considered close to a point
%            in the "representative set"
%        z0: [optional] set of representative points
%            If given, the function operates in incremental mode;
%            that is, the computation starts from z0 (which is used to
%            initialize z) rather than the empty set
% 
% *** Outputs ***
%         z: matrix with the chosen representative points
%    ns_idx: indices of the points in x added to the representative set
%       idx: indices of points in the representative set that is
%            closest to each point in x
%
% The data reduction procedure follows the basic ideas of Platt's
% novelty criterion, without taking the "model error" into consideration.
%
% This function implements the "sequencial search" form of the novelty
% selection. Simply put, the function goes through the data and adds the
% points to the "representative set" if the minimum distance to all the
% other representative points is larger than delta.

% If you use this code in a publication, please cite the paper:
%   Antonio R. C. Paiva and Tolga Tasdizen,
%   "Fast semi-supervised image segmentation using novelty selection,"
%   in Proceedings of ICASSP, Dallas, TX, USA, March 2010
%
% Antonio Paiva, SCI Institute, University of Utah
% This code is provided free but WITHOUT ANY WARRANTY.

%-------------------------------------------------
% process input arguments

if (nargin < 2)
	error('At least two arguments are required.');
elseif (delta <= 0)
	z = x;
	return;
end
[d N] = size(x);
delta = delta^2;	% this way one can compare to squared distances directly

ns_idx = zeros(1,N);
idx = zeros(1,N);
if (nargin < 3) || isempty(z0)
	% move the first point from x to z, prevent z from being empty
	z = [x(:,1), zeros([d N-1])];
	ns_idx(1) = 1;
	idx(1) = 1;
	si = 2;
	n = 1;				% index of the last position of z occupied
	n0 = 0;
elseif (size(z0,1) ~= d)
	error('The dimensionality of z0 does not match the input data.');
else
	z = [z0, zeros([d N])];
	n = size(z0,2);		% index of the last position of z occupied
	n0 = n;
	si = 1;
end

%-------------------------------------------------
% determine representative points

zNormSqr = sum(z.^2,1);
xNormSqr = sum(x.^2,1);

for i = si:N
	% compute squared Euclidean distance of x(:,i) to all representative points
	dSqr = xNormSqr(i) + zNormSqr(1:n) - 2 .* (x(:,i)' * z(:,1:n));
	[d j] = min(dSqr);
	if (d > delta)
		% add point to representative set
		n = n + 1;
		z(:,n) = x(:,i);
		zNormSqr(n) = xNormSqr(i);
		ns_idx(n-n0) = i;
		idx(i) = n;
	else
		idx(i) = j(1);
	end
end
z = z(:,1:n);
ns_idx = ns_idx(1:n);

